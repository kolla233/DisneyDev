# -*- coding: utf-8 -*-
"""
Created on Thu May 16 11:33:13 2019

@author: bonaresh
"""

# importing python module "unittest"

import unittest
import filecmp
import subprocess
from ds.core.configmgr import ConfigManager


class ETL_Operations_Test_Scenarios(unittest.TestCase):
    
    def test_directmovetrueLtoL(self):
        """perform HDFS to HDFS file movement operations when direct move = true """
        cm = ConfigManager("CM_FSD_FILEMOVER",flow="EXECUTION_TEST")                       
        cmd = "python /root/data-solutions/fsd/consumption/src/scripts/common/ETLOperations.py EXECUTION_TEST  user/hdfshcsc/  /home/abcd/ fileid3  /root/hcsc/etl_logs --debug"
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return = proc.returncode
        if s_return == 0:
                print("Script has been executed successfully")
                src_path = cm["flow_fileid1","src_path"]
                tgt_path = cm["flow_fileid1","tgt_path"]
                Expected_path = cm["flow_fileid1","Expected_path"]

        """ Perform data validaition between source and target files """
        Testresult = self.assertTrue(filecmp.cmp(src_path,tgt_path))
        if Testresult == None:
                 print ("File comparison has been done successfully")
        else:
                 print ("File comparison has been failed")
