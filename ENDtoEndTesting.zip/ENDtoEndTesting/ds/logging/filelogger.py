from __future__ import unicode_literals

import sys

import time,datetime
import uuid
import posixpath

from ds.logging import getChild,FsdLogger,Stopwatch
from ds.hadoop.hdfs import HDFSFile
from ds.hadoop.hive import HiveQuery,HiveTableInfo

from ds.core.utils import get_environment,get_fs_env,get_current_user
from ds.core.configmgr import get_flow_id,ConfigManager

filelogger = getChild(FsdLogger,"filelogger")

FILELOG_DB = "finance_acturl_data_smith"
FILELOG_TBL = "FILE_MV_LOG"
FILELOG_NM = "filelog.csv"

FILECHECK_HQL = """WITH TMP AS (
SELECT TARG_FILE_LOC_TXT,FILE_MV_END_TS
FROM FINANCE_ACTURL_DATA_SMITH.FILE_MV_LOG 
WHERE FILE_NM = '${hivevar:filenamechk}'
ORDER BY FILE_MV_END_TS DESC
LIMIT 1
)
SELECT A.TARG_FILE_LOC_TXT
FROM TMP A
WHERE A.TARG_FILE_LOC_TXT NOT LIKE '%/BadFile/%';
"""

def check_for_file(filename):
    """ Checks for 'filename' present in the FSD file log as a valid file in the lake.
        Will return the HDFS path if found, or None for either a remediated file or no file present.
    """
    filename = posixpath.split(filename)[1]
    filelogger.debug("Checking history for filename: '%s'" % (filename))
    fileloq_query = HiveQuery(FILECHECK_HQL)
    fileloq_query.execute(hivevar={'filenamechk':filename})
    result_value = fileloq_query.results
    return result_value

class FileLogger(Stopwatch):
    """ Context manager that's used to track file movements within the FSD data lake."""
        
    def __init__(self,filename,*args,**kwargs):
        """ Sets up the context manager for file logging. Expects the following arguments [(m) MANDATORY   (o) OPTIONAL ]:
            
            (m) filename
            (m) source info (matching pairs of: SRC_LAYER, SRC_PATH, SRC_DB + SRC_TBL )
            (m) target info (matching pairs of: TGT_LAYER, TGT_PATH, TGT_DB + TGT_TBL )
            
            (o) description of operation
        """
        super(FileLogger,self).__init__(*args)
        
        lower_kwargs = dict((k.lower(),v) for k,v in kwargs.iteritems())
        
        # builds the path to the filelog file (filefilefilefile...)
        logfile_path = posixpath.join(HiveTableInfo(FILELOG_DB,FILELOG_TBL).path,FILELOG_NM)
        self.logfile = HDFSFile(logfile_path)
        
        # sometimes they'll send us a full HDFS path, so let's just get the filename only
        self.filename = posixpath.split(filename)[1]
        
        # get configmanager obj for our filename
        self.file_cm = ConfigManager(filename=self.filename)
        
        # sysname is defined in the general flow setup for each flow
        self.sysname = self.file_cm['flow_setup','source_system']

        self.desc = lower_kwargs.get('desc','')
        self.exec_user = get_current_user()
        
        # handle various source definitions
        try:
            # if provided with either table or layer definition
            src_tbl = lower_kwargs.get('src_tbl',self.file_cm['flow_%s' % (lower_kwargs['src_layer']),'flow_tbl'])
            src_db = lower_kwargs.get('src_db',self.file_cm['flow_%s' % (lower_kwargs['src_layer']),'flow_db'])
            self.source = HiveTableInfo(src_db,src_tbl).path
        except KeyError:
            # otherwise look for a path
            self.source = lower_kwargs.get('src_path',None)
            if not self.source:
                error_msg = "Must provide some kind of source information (src_layer,src_tbl/db,src_path)"
                filelogger.error(error_msg)
                raise Exception(error_msg)
        
        # handle various target definitions
        try:
            # if provided with either table or layer definition
            tgt_tbl = lower_kwargs.get('tgt_tbl',self.file_cm['flow_%s' % (lower_kwargs['tgt_layer']),'flow_tbl'])
            tgt_db = lower_kwargs.get('tgt_db',self.file_cm['flow_%s' % (lower_kwargs['tgt_layer']),'flow_db'])
            self.target = HiveTableInfo(tgt_db,tgt_tbl).path
        except KeyError:
            # otherwise look for a path
            self.target = lower_kwargs.get('tgt_path',None)
            if not self.source:
                error_msg = "Must provide some kind of target information (tgt_layer,tgt_tbl/db,tgt_path)"
                filelogger.error(error_msg)
                raise Exception(error_msg)            
    
    
    def __exit__(self,exception_type, exception_value, traceback):
        super(FileLogger,self).__exit__()
        
        # boilerplate logvals
        logvals = []
        logvals.append(datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'))
        logvals.append(self.exec_user)
        logvals.append(self.sysname)
        logvals.append(str(uuid.uuid4())) # why are we adding GUIDs here?
        logvals.append(self.filename)
        logvals.append(self.source)
        logvals.append(self.target)
        logvals.append(datetime.datetime.utcfromtimestamp(self.start).strftime('%Y-%m-%d %H:%M:%S'))
        logvals.append(datetime.datetime.utcfromtimestamp(self.end).strftime('%Y-%m-%d %H:%M:%S'))
        logvals.append(self.desc)
        
        if not exception_type:
            # if FileLogger context exited successfully...
            logvals.append("PASS")
        else:
            # if FileLogger failed somehow...
            logvals.append("FAIL (%s: %s)" % (str(exception_type),str(exception_value)))
        
        self.write_to_log(*logvals)
    
    def write_to_log(self,*vals):
        self.logfile.write("|".join(vals)+"\n")
