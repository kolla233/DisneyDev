""" 
    FSD base logger configuration and setup.

"""
import logging, time

# Formatter to use UTC (always UTC!)
class UTCFormatter(logging.Formatter):
    converter = time.gmtime

# Basic log formatting
FsdFormatter = UTCFormatter('%(asctime)s %(name)-25s %(levelname)-8s %(message)s',
                      datefmt='%Y-%m-%d %H:%M:%S')

FsdLogger = logging.getLogger('fsd')
FsdLogger.setLevel(logging.DEBUG)

# Console handler
console = logging.StreamHandler()
console.setFormatter(FsdFormatter)
console.setLevel(logging.DEBUG)
FsdLogger.addHandler(console)

def getChild(logger,name):
    """ Reproduces the behavior of 'getChild' on a Logger instance in 2.7."""
    return logging.getLogger(logger.name+"."+name)

def setDebug():
    """ Sets the FsdLogger instance to log level DEBUG."""
    FsdLogger.setLevel(logging.DEBUG)

def setInfo():
    """ Sets the FsdLogger instance to log level INFO."""
    FsdLogger.setLevel(logging.INFO)

def setWarn():
    """ Sets the FsdLogger instance to log level WARN."""
    FsdLogger.setLevel(logging.WARN)

def setError():
    """ Sets the FsdLogger instance to log level WARN."""
    FsdLogger.setLevel(logging.ERROR)