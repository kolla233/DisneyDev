""" Utility functions for FSD library."""
from __future__ import unicode_literals
import socket
import getpass
import datetime

# Environment definition strings
ENV_DEV = "dev"
ENV_FAKEDEV = "fakedev"
ENV_TEST = "test"
ENV_PROD = "prod"
ENV_SAND = "sand"

def get_environment():
    """
        Returns whether the running environment is one of the following:
        - dev
        - test
        - prod
        - sandbox
        
        Determination is [usually] based on the first character of the hostname. If the
        first character is not valid (i.e. a number, or a workstation host) the
        function returns dev.
    """
    # Get first character of lowercase hostname
    hostname = socket.gethostname()
    env_char = hostname[0]
    env_return = None
    if hostname == "twauslaenapp03":
        env_return = ENV_FAKEDEV
    elif env_char == 'p':
        env_return = ENV_PROD
    elif env_char == 't':
        env_return = ENV_TEST
    elif env_char == 'd':
        env_return = ENV_DEV
    elif env_char == 's':
        env_return = ENV_SAND
    else:
        print("No server available")
        exit(2)
    return env_return

# Filesystem path variable definitions

FS_ENVS = {
    ENV_DEV:'dev',
    ENV_FAKEDEV:'tst', # fakedev is on a test server, no dev path provided in the linux FS
    ENV_TEST:'tst',
    ENV_PROD:'prod',
    ENV_SAND:'dev'
    }

def get_fs_env():
    return FS_ENVS[get_environment()]

def get_current_user():
    """ Wrapper [for uniformity's sake] to get the current user."""
    return getpass.getuser()

def get_utc_file_timestamp():
    """ Returns a string of the UTC timestamp in the format:
        'YYYYMMDD_HHMMSS'
    """
    return datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    

# fairly simple caseinsensitivedict implementation
from collections import MutableMapping

class CaseInsensitiveDict(MutableMapping):
    """ Simple implementation of a dict where all keys are lowercase
        and accepts mixed case keying to return the lowercase keys."""
    
    @staticmethod
    def process_key(keyval):
        # if string
        if isinstance(keyval,basestring):
            return keyval.lower()
        # if simple iterable
        elif hasattr(keyval,'__iter__'):
            itercls = keyval.__class__
            return itercls(v.lower() for v in keyval)
        else:
            return keyval
    
    def __init__(self,newdict=None):
        self._dict = {} # internal dictionary of (searchkey):(realkey,val)
        if newdict:
            tempdict = dict(newdict)
            self._dict.update(dict((self.process_key(k),(k,v)) for k,v in tempdict.iteritems()))
    
    def __getitem__(self, key):
        return self._dict[self.process_key(key)][1]
    
    def __setitem__(self,key,val):
        self._dict[self.process_key(key)] = (key,val)
    
    def __delitem__(self,key):
        self._dict.__delitem__(self.process_key(key))
    
    def __iter__(self):
        return iter(self._dict)
    
    def __len__(self):
        return len(self._dict)
    
    def __unicode__(self):
        return unicode(dict((k,val) for k,(orig,val) in self._dict.iteritems()))
    
    def __str__(self):
        return unicode(self).encode('utf-8')
    
    def __repr__(self):
        return ("""%s(%s)""" % (self.__class__.__name__,repr(self.orig()))).encode("utf-8")
    
    def orig(self):
        return dict((orig,val) for k,(orig,val) in self._dict.iteritems())


def test_caseinsensitivedict():
    """ quick unit test for CaseInsensitiveDict class."""
    d1 = {'Alice':0,'Bob':1,'Carol':2}
    d2 = {
          ('Alice','Alice Smith'):0,
          ('Bob','Bob Smith'):1,
          ('Carol','Carol Smith'):2
          }
    
    c1 = CaseInsensitiveDict() # blank control
    print "c1:",c1
    
    c2 = CaseInsensitiveDict()
    print "c2:",c2
    for k,v in d1.iteritems():
        c2[k] = v
    print "c2:",c2
    print "c2 orig:",c2.orig()
    repr(c2)
    
    for k,v in d1.iteritems():
        print "c2[%s]==d1[%s]" % (k,k),c2[k]==d1[k]
    
    c3 = CaseInsensitiveDict()
    print "c3:",c3
    for k,v in d2.iteritems():
        c3[k] = v
    print "c3:",c3
    print "c3 orig:",c3.orig()
    repr(c3)
    
    for k,v in d2.iteritems():
        print "c3[%s]==d2[%s]" % (k,k),c3[k]==d2[k]
    
    return c3