from __future__ import unicode_literals
""" FSD common library implementation of a configuration file wrapper class.
    Based on SafeConfigParser with some customizations and convenience changes.
"""
from ds.core.localfs import LocalFile
from ds.hadoop.hdfs import HDFSFile

from ConfigParser import SafeConfigParser,MissingSectionHeaderError,NoOptionError,NoSectionError
from ast import literal_eval # for handling truth values from strings
from collections import OrderedDict, Mapping, MutableMapping
from itertools import chain

from ds.logging import getChild,FsdLogger,setDebug,setInfo
conflog = getChild(FsdLogger,"config")

# static vars to mark FULL or SIMPLE style config parsing
PARSE_FULL = 1
PARSE_SIMPLE = 2

class ConfigFile(Mapping):
    """ Core class for interacting with configuration files (parsing, writing, etc.)
        Most behavior is split into "full" .ini type configs and "simple" k=v configs.
    """
    
    def __init__(self,path,*args,**kwargs):
        self.path = path
        # checks optional keyword argument 'filetype' for HDFS or Local, defaults to LocalFile
        self._filecls = HDFSFile if kwargs.get('filetype','local').lower().strip() == 'hdfs' else LocalFile
        self.file = self._filecls(self.path) # set up actual file object
        conflog.debug("Configuration file of type '%s' located at '%s' exists: %s" % (self.file.__class__.__name__,self.file.path,self.file.exists))
        if kwargs.get('checkexists',False):
            if not self.file.exists:
                raise Exception("Config file at path '%s' does not exist." % (self.file.path))
        try:
            # Assume it's a ConfigParser-style file, if it isn't it'll throw an exception
            self._conf = SafeConfigParser()
            self._conf.readfp(self.file.get_reader())
            self.parsestyle = PARSE_FULL # Using the SafeConfigParser with .ini style headers
        except MissingSectionHeaderError as e:
            # @TODO: See what happens if a file does't exist!
            # If it throws a particular exception, we process it as a Simple style
            conflog.debug("Configuration file at '%s' has no headers, processing as simple-style config." % (self.file.path))
            self.parsestyle = PARSE_SIMPLE
            self._conf = self.parse_simple(self.file.get_reader())
    
    @staticmethod
    def parse_simple(confreader):
        """ Alternate method for parsing than SafeConfigParser.
            Reads a [text] file line-by-line and splits on the first '=' sign.
            Everything to the left is a key, everything to the right is a value.
            Returns an OrderedDict of that.
        """
        parsed = OrderedDict()
        for ln in confreader.readline():
            try:
                k,v = ln.split("=",1)
                if k in parsed:
                    raise KeyError("Key '%s' is duplicated in the configuration file." % (k))
                parsed[k] = v
            except ValueError, e:
                error_msg = "Line item '%s' does not parse to an expected k=v format." % (ln)
                conflog.warn(error_msg)
                raise ValueError(error_msg)
        return parsed
    
    @property
    def headers(self):
        """ Returns headers (sections) present in the config file. Simple configs have no headers."""
        if self.parsestyle == PARSE_FULL:
            return self._conf.sections()
        else:
            return []
    
    def __getitem__(self,key):
        """ Behaves a little differently than a traditional dict lookup.
            Accepts a text string OR an iterable of values.
            If a string:
                if FULL:    Returns the OrderedDict for a the header matching <string>
                if SIMPLE:  Returns the value for the key matching <string>
            If an iterable:
                if FULL:    Returns the value for the header and key matching <string>
                if SIMPLE:  ??? (raise keyerror,return multiple values...?)
        """
        key_str = isinstance(key,basestring) # both 'str' and 'unicode' are related to 'basestring'
        if self.parsestyle == PARSE_FULL:
            # Full files have headers as their first key
            if key_str:
                # returns all items within a header, repacked into an ordereddict 
                return OrderedDict(self._conf.items(key))
            else:
                # returns a specific value by header and option
                try:
                    return self._conf.get(key[0],key[1])
                except (NoSectionError,NoOptionError), e:
                    raise KeyError("Key (%s,%s) not found in config." % (key[0],key[1]))
        else:
            # If you're working with a simple file, just return the value, or a KeyError if not a str key
            if not key_str:
                raise KeyError("Cannot access tuples of keys ('%s') in a simple config file." % (unicode(key)))
            return self._conf[key]
    
    def __iter__(self):
        """ Iterates over 2-tuples (simple) or 3-tuples (full) for config file contents."""
        if self.parsestyle == PARSE_FULL:
            return iter(chain(*([(hdr,k) for k,v in self._conf.items(hdr)] for hdr in self.headers)))
        else:
            return self._conf.iterkeys()
    
    def __len__(self):
        """ Length of the ConfigFile is provided as the number of complete ([header],key,value) tuples."""
        return len(list(self.__iter__()))

class MutableConfigFile(ConfigFile,MutableMapping):
    """ NOT IMPLEMENTED, TODO. Class of ConfigFile that also supports writing to the dictionary."""
    
    def __setitem__(self,key,value):
        """ Behaves a little differently than a traditional dict lookup.
            Accepts a text string OR an iterable of values.
            If a string:
                if FULL:    Returns the OrderedDict for a the header matching <string>
                if SIMPLE:  Returns the value for the key matching <string>
            If an iterable:
                if FULL:    Returns the value for the header and key matching <string>
                if SIMPLE:  ??? (raise keyerror,return multiple values...?)
        """
        pass
    
    def __delitem__(self,key):
        pass