""" Local filesystem objects for manipulating directories + files."""
import os, shutil
import hashlib
import datetime
from itertools import ifilter,ifilterfalse,imap,chain
from collections import namedtuple

from ..core import BaseFile, BaseDirectory, BaseFSException, ShellIOWrapper, ShellCommand

# Set up logging
from ds.logging import getChild,FsdLogger,Stopwatch
fs_log = getChild(FsdLogger,"core.fs")

class LocalFSException(BaseFSException):
    pass

class LocalFile(BaseFile):
    """ Provides a FSD BaseFile-compliant object wrapper to local filesystem files."""
        
    def process_path(self,path_str):
        """ Strips any quoting off of the path string provided."""
        return path_str.strip(""" "'`""")

    def get_checksum(self):
        """ Returns MD5 hash of the file object."""
        hash = hashlib.md5()
        chunkbytes = 65536 # default blocksize for md5 iteration
        with open(self.path,'rb') as f:
            for chunk in iter(lambda: f.read(chunkbytes),b''):
                hash.update(chunk)
        return hash.hexdigest()
    
    def size_bytes(self):
        """ Should return the size, in bytes, of the file."""
        return os.stat(self.path).st_size

    def file_exists(self,path=None):
        """ Returns a boolean value of whether the file exists."""
        if not path:
            path = self.path
        return os.path.isfile(path)

    def get_writer(self,mode='w'):
        """ Returns the file object for writing.
            Valid modes supported are 'w' and 'a', not updates. 
        """
        if mode not in ('a','w'):
            raise ValueError("Invalid file mode '%s' provided - valid modes are 'w' and 'a'." % (mode))
        return ShellIOWrapper(open(self.path,mode))

    def get_reader(self):
        """ Returns the file object for reading. """
        return ShellIOWrapper(open(self.path,'r'))
    
    def create(self,contents=None):
        """ Creates an empty file if it doesn't exist."""
        if not self.exists:
            if contents:
                with self.get_writer(mode='w') as w:
                    w.write(contents.read())
            else:
                open(self.path,'a').close()
                
    def toHDFS(self, dest_path):
        """ Makes a copy of the file at 'dest_path'."""
        fs_log.info("Copying file '%s' to '%s'" % (self.path, dest_path))
        args_list = ["fs", "-copyFromLocal", self.path, dest_path]
        copy_cmd = ShellCommand(executable="hadoop", args=args_list)
        copy_cmd.execute()  
    
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        objpath,objname = self.path.rsplit(os.sep,1)
        newpath = self.path[:len(objpath)+1] + new_name
        os.rename(self.path,newpath)
    
    def copy(self,dest_path,overwrite=False):
        """ Copies the file to 'dest_path', deleting the file 
            at 'dest_path' first if it exists AND overwrite is selected."""
        if overwrite and self.file_exists(dest_path):
            os.remove(dest_path)
        shutil.copy2(self.path,dest_path)

    def move(self,dest_path,overwrite=False):
        """ Moves the file to 'dest_path', deleting the file
            at 'dest_path' first if it exists AND if overwrite is selected."""
        if overwrite and self.file_exists(dest_path):
            os.remove(dest_path)
        shutil.move(self.path,dest_path)
    
    def delete(self):
        """ Deletes the file at self.path."""
        os.remove(self.path)
        
    def get_stats(self):
        LS_PROPS = namedtuple('ls_props',('dir','permissions','userid','groupid','filesize','mod_timestamp','path'))
        dir_contents = [self.LS_PROPS(os.path.isdir(f),fstat.st_mode,fstat.st_uid,fstat.st_gid,fstat.st_size,datetime.datetime.utcfromtimestamp(fstat.st_mtime),f) for f,fstat in dir_listing]
        

class LocalDirectory(BaseDirectory):
    """ Provides a FSD BaseDirectory-compliant object wrapper to local filesystem directories."""
    NT_LONGPATHS = u"\\\\?\\"
    LS_PROPS = namedtuple('ls_props',('dir','permissions','userid','groupid','filesize','mod_timestamp','path'))
    
    def process_path(self,path_str):
        """ Process an incoming path string before it's stored on the object."""
        return path_str.strip(""" "'`""").rstrip(os.sep)

    def list_contents(self,dirs=True,files=True,recursive=False,wildcard_path=False):
        """ Returns a list of self.LS_PROPS namedtuples representing the contents of this directory."""
        use_path = self.path
        if os.name == 'nt':
            if self.NT_LONGPATHS not in use_path:
                use_path = unicode(self.NT_LONGPATHS + use_path)
                fs_log.debug("Using NTFS workaround for long paths. Rewritten path: '%s'" % (use_path))
        
        if wildcard_path :
            import glob
            dir_listing = glob.glob(self.path)
        elif recursive:
            dir_listing =  list(chain(*chain(*[([os.path.join(r,f) for f in files],[os.path.join(r,d) for d in dirs]) for r,dirs,files in os.walk(use_path)])))
        else:
            dir_listing = [os.path.join(use_path,p) for p in os.listdir(use_path)]
        fs_log.debug("'listdir' yielded %d entries for path '%s'." % (len(dir_listing),use_path))
        
        dir_listing = [(f,os.stat(f)) for f in dir_listing]
        dir_contents = [self.LS_PROPS(os.path.isdir(f),fstat.st_mode,fstat.st_uid,fstat.st_gid,fstat.st_size,datetime.datetime.utcfromtimestamp(fstat.st_mtime),f) for f,fstat in dir_listing]
        fs_log.debug("Properties for path '%s': %s" % (use_path,dir_contents))
        if not (dirs and files):
            if dirs:
                dir_contents = ifilter(lambda x: x.dir, dir_contents)
            elif files:
                dir_contents = ifilterfalse(lambda x: x.dir, dir_contents)
        return dir_contents

    def iter_objects(self,filelist):
        """ Returns a generator of LocalDirectories or LocalFiles for each [presumed] self.LS_PROPS namedtuple in 'filelist'."""
        return (LocalDirectory(x.path) if x.dir else LocalFile(x.path) for x in filelist)

    def size_bytes(self):
        """ Should return the size, in bytes, of the file."""
        use_path = self.path
        if os.name == 'nt':
            if self.NT_LONGPATHS not in use_path:
                use_path = self.NT_LONGPATHS + use_path
                fs_log.debug("Using NTFS workaround for long paths. Rewritten path: '%s'" % (use_path))
        size = sum(imap(sum,((os.path.getsize(os.path.join(r,f)) for f in files) for r,d,files in os.walk(use_path))))
        return size

    def dir_exists(self,path=None):
        if not path:
            path = self.path
        return os.path.isdir(path)

    def create(self):
        """ Creates the directory at self.path if it doesn't already exist."""
        if not self.exists:
            os.mkdirs(self.path)
    
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        objpath,objname = self.path.rsplit(os.sep,1)
        newpath = self.path[:len(objpath)+1] + new_name
        os.rename(self.path,newpath)
    
    def copy(self,dest_path,overwrite=False):
        """ Copies, optionally overwriting, the directory at self.path to dest_path."""
        if overwrite and self.dir_exists(dest_path):
            os.rmdir(dest_path) # We don't use rmtree here intentionally
        shutil.copytree(self.path,dest_path)            

    def copy_contents(self,dest_path,overwrite=False):
        """ Copies, optionally replacing (will clear before copying!), the directory at self.path to dest_path."""
        if overwrite and self.dir_exists(dest_path):
            os.rmdir(dest_path) # We don't use rmtree here intentionally
        for obj in self: # Iterate through contents
            src_prefix = os.path.commonprefix(self.path,obj.path).rfind(os.sep)
            obj_dest = os.path.join(dest_path,obj.path[src_prefix+1:])
            obj.copy(obj_dest)
    
    def move(self,dest_path,overwrite=False):
        """ Moves, optionally overwriting, the directory at self.path to dest_path.
            Will raise a LocalFSException if the folder exists but overwrite is False.
            Bear in mind 'overwrite' will clear before copying, not just overwrite duplicate contents!
        """
        dir_there = self.dir_exists(dest_path)
        if overwrite and dir_there:
            os.rmdir(dest_path) # We don't use rmtree here intentionally
        elif dir_there:
            raise LocalFSException("Destination '%s' already exists, but overwrite not specified." % (dest_path))
        shutil.move(self.path,dest_path)

    def move_contents(self,dest_path,overwrite=False):
        """ Moves, optionally overwriting, the contents of the directory at self.path to dest_path.
            Will raise a LocalFSException if the folder exists but overwrite is False.
            Bear in mind 'overwrite' will clear before moving, not just overwrite duplicate contents!
        """
        dir_there = self.dir_exists(dest_path)
        if overwrite and dir_there:
            os.rmdir(dest_path) # We don't use rmtree here intentionally
        elif dir_there:
            raise LocalFSException("Destination '%s' already exists, but overwrite not specified." % (dest_path))
        for obj in self: # Iterate through contents
            src_prefix = os.path.commonprefix(self.path,obj.path).rfind(os.sep)
            obj_dest = os.path.join(dest_path,obj.path[src_prefix+1:])
            obj.move(obj_dest)

    def delete(self,recursive=False):
        """ Deletes the directory, and optionally all of its child directories and contents."""
        if recursive:
            shutil.rmtree(self.path)
        else:
            os.rmdir(self.path)
            
    def clear(self,recursive=False):
        """ Removes, optionally recursively, the contents of the directory."""
        for obj in self.files:
            obj.delete()
        if recursive:
            for obj in self.dirs:
                obj.delete(recursive=True)
            