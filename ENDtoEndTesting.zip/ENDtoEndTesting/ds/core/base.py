""" Fundamental FSD base classes. """
# Import the ABCMeta metaclass and @abstractmethod decorator
from abc import ABCMeta,abstractmethod
from collections import namedtuple

class BaseQuery(object):
    """ Base class representing a database query operation."""
    
    __metaclass__ = ABCMeta

    """ Base class for query operations, provides common interface
        for query-like operations - Hive, SQL, DB2, etc."""
    
    def __init__(self,query=None,*args,**kwargs):
        self.query = query
        self._results = None
        self._results_metadata = {}
        
    # Defines query-side handling
    
    @property
    def query(self):
        """ Returns the private "query" property."""
        return self._query
    
    @query.setter
    def query(self,query):
        """ Processes the provided string through "process_query"
            and populates the private "_query" property."""
        self._query = self.process_query(query)
    
    def process_query(self,query,*args,**kwargs):
        """ Perform any syntax checking or modifications
            to query strings provided to the object."""
        return query    
    
    # Defines results-side handling
    
    @property
    def results(self):
        """ Returns the private "results property."""
        return self._results
    
    @results.setter
    def results(self,results):
        """ Setter for the .results property to re-route through process_results()."""
        self._results = self.process_results(results)
    
    def process_results(self,results,*args,**kwargs):
        """ Optional post-processing for the output of the query."""
        return results
    
    @abstractmethod
    def execute(self,*args,**kwargs):
        """ Executes the query."""
        raise NotImplementedError

    # Defines utility methods on the class
    
    def __unicode__(self):
        """ Provides a string representation of the object."""
        if self.query:
            return "%s: %s" % (self.__class__.__name__,self.query)
        else:
            return "%s: (no query)" % (self.__class__.__name__)
        
    def __eq__(self,other):
        """ Simple equality method comparing both .results properties."""
        try:
            return self.results == other.results
        except AttributeError:
            return super(BaseQuery, self) == other


class BaseFSException(Exception):
    """ Provides a filesystem exception base class."""
    pass

class BaseFile(object):
    """ Base class for representing a file-like object."""
    
    __metaclass__ = ABCMeta
    
    def __init__(self,path,*args,**kwargs):
        """ BaseFile expects a path (to the file) argument to define the object."""
        self._path = None
        self._writer = None
        self._metadata = {}
        self.path = path
    
    def __unicode__(self):
        """ Returns the path of the object."""
        return self.path
    
    def __str__(self):
        return unicode(self).encode('utf-8')

    def __repr__(self):
        return ("""%s("%s")""" % (self.__class__.__name__,str(self))).encode("utf-8")
    
    def read(self):
        """ Shortcut method to read data in one go."""
        with self.reader as r:
            return r.read()
    
    def write(self,value):
        """ Shortcut method for writing data in one go."""
        with self.writer as f:
            f.write(value)    
    
    def __len__(self):
        """ A BaseFile's len() is its size in bytes."""
        return self.size_bytes()
    
    @property
    def path(self):
        """ Returns a quote-wrapped path string."""
        return self._path

    @path.setter
    def path(self,path_str):
        """ Redirects .path setting operations through .process_path() first."""
        self._path = self.process_path(path_str)    
    
    @property
    def exists(self):
        """ Calls the .file_exists() method to validate if the underlying file is present."""
        return self.file_exists()
    
    @property
    def reader(self):
        """ Shortcut for .get_reader() method."""
        return self.get_reader()
    
    @property
    def writer(self):
        """ Returns a file-like object for writing to the file.
            By default, the writer will APPEND if the file already exists.
        """
        if not self._writer or self._writer.closed:
            write_mode = "w"
            if self.exists:
                write_mode = "a"
            self._writer = self.get_writer(mode=write_mode)
        return self._writer
    
    @property
    def checksum(self):
        """ Shortcut method to .get_checksum()."""
        return self.get_checksum()
    
    @abstractmethod
    def process_path(self,path_str):
        """ Process an incoming path string before it's stored on the object."""
        pass    
    
    @abstractmethod
    def get_checksum(self):
        """ Should return a string value that uniquely represents the file, 
            usually a MD5 hash or the platform's equivalent."""
        pass
    
    @abstractmethod
    def size_bytes(self):
        """ Should return the size, in bytes, of the file."""
        pass
    
    @abstractmethod
    def file_exists(self,path=None):
        """ Should return True if the file exists on the filesystem."""
        pass
    
    @abstractmethod
    def get_writer(self,mode=None):
        """ Should return a Python file-like object for writing to the file."""
        pass
    
    @abstractmethod
    def get_reader(self):
        """ Should return a Python file-like object for reading from the file."""
        pass
    
    @abstractmethod
    def create(self,contents=None):
        """ Either creates a blank file or accepts a file-like object 
            as the 'contents' argument."""
        pass
    
    @abstractmethod
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        pass
    
    @abstractmethod
    def copy(self,dest_path,overwrite=False):
        """ Makes a copy of the file from self.path to dest_path."""
        pass
    
    @abstractmethod
    def move(self,dest_path,overwrite=False):
        """ Moves the file from self.path to dest_path."""
        pass
        
    @abstractmethod
    def delete(self):
        """ Deletes the file from self.path."""
        pass

class BaseDirectory(object):
    """ Base class for representing a directory/folder-like object."""
    
    __metaclass__ = ABCMeta
    
    def __init__(self,path,*args,**kwargs):
        self._path = None # HDFS path including filter
        self.path = path
    
    # Some way to handle * and wildcard across platforms
    
    def __unicode__(self):
        """ Returns the path of the object."""
        return self.path
    
    def __str__(self):
        return unicode(self).encode('utf-8')
    
    def __repr__(self):
        return ("""%s("%s")""" % (self.__class__.__name__,str(self))).encode("utf-8")
    
    def __iter__(self):
        return iter(self.iter_objects(self.list_contents()))
    
    def __len__(self):
        """ Returns the number of items in the directory."""
        return len(self.list_contents())
    
    @property
    def path(self):
        """ Returns a quote-wrapped path string."""
        return self._path

    @path.setter
    def path(self,path_str):
        self._path = self.process_path(path_str)
    
    @property
    def exists(self):
        return self.dir_exists()
    
    @property
    def files(self):
        """ Returns a list of file objects present in the directory."""
        return list(self.iter_objects(self.list_contents(dirs=False,files=True)))

    @property
    def dirs(self):
        """ Returns a list of directory objects present in the directory."""
        return list(self.iter_objects(self.list_contents(dirs=True,files=False)))
    
    @abstractmethod
    def process_path(self,path_str):
        """ Process an incoming path string before it's stored on the object."""
        pass
    
    @abstractmethod
    def list_contents(self,dirs=True,files=True,recursive=False):
        pass
    
    @abstractmethod
    def iter_objects(self,filelist):
        pass
    
    def iter_contents(self,dirs=True,files=True,recursive=False):
        """ Convenience method combining .list_contents and .iter_objects 
            to go straight to iterating contents by object."""
        return self.iter_objects(self.list_contents(dirs,files,recursive))
    
    @abstractmethod
    def size_bytes(self):
        """ Should return the size, in bytes, of the file."""
        pass
    
    @abstractmethod
    def dir_exists(self,path=None):
        pass
    
    @abstractmethod
    def create(self):
        """ Creates an empty directory on the filesystem. """
        pass
    
    @abstractmethod
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        pass
    
    @abstractmethod
    def copy(self,dest_path,overwrite=False):
        """ Copies the directory and its contents from self.path to dest_path."""
        pass
    
    @abstractmethod
    def copy_contents(self,dest_path,overwrite=False):
        """ Copies only the contents within self.path to dest_path."""
        pass
    
    @abstractmethod
    def move(self,dest_path,overwrite=False):
        """ Moves the directory and its contents from self.path to dest_path."""
        pass
    
    @abstractmethod
    def move_contents(self,dest_path,overwrite=False):
        """ Moves only the contents from the directory in self.path to dest_path."""
        pass
    
    @abstractmethod
    def delete(self,recursive=False):
        """ Deletes the folder, optionally recursively."""
        pass
    
    @abstractmethod
    def clear(self,recursive=False):
        """ Deletes only the contents of the directory."""
        pass 