"""
    Base classes that support atomic-ish operations
    when used as directed.
"""
from abc import ABCMeta
from collections import MutableSequence
import sys # Need 'sys' to use actual exception, not rebased traceback

class AtomicOperation:
    """ Abstract base class supporting basic atomic behaviors
        through the use of execution, cleanup actions, and
        optional confirmation checks.

        Provides a standard interface for handling operation execution, commit, and rollback:
         - .execute() performs some action and will throw if it fails
         - .confirm() checks the action behaved as expected, returning boolean
         - .cleanup_fail() performs cleanup actions if the operation were to fail
         - .cleanup_success() performs cleanup actions if the operation succeeds

        AtomicOperations may also be chained together in the AtomicOperationCollection which provides
        an ability to pass arguments from one Operation to another via the .chain_args settable property.
    """

    __metaclass__ = ABCMeta

    @property
    def chain_args(self):
        """ Returns args, kwargs for next iteration if AtomicOperation is executed in a chain."""
        try:
            return self.ch_args,self.ch_kwargs
        except AttributeError:
            # ch_args, ch_kwargs are only initialized when chain_args are set
            return [],{}

    @chain_args.setter
    def chain_args(self,value):
        self.ch_args,self.ch_kwargs = value # Unpack tuple and set values
    
    def execute(self,*args,**kwargs):
        """ Performs the operation."""
        raise NotImplementedError

    def cleanup_success(self):
        """ Performs any required cleanup after the operation has succeeded."""
        raise NotImplementedError

    def cleanup_failure(self):
        """ Performs rollback or cleanup of operation after failure."""
        raise NotImplementedError

    def confirm(self):
        """ Confirms the correct behavior of the executed operation.
            confirm() should return True or False. """
        raise NotImplementedError
    
    def run(self,*args,**kwargs):
        """ Convenience method that will:
             1. executes the operation
             2. rolls back if an exception is raised
             3. confirms success of the operation
             4. rolls back if not confirmed, runs cleanup if confirmed
             5. returns results of execute, if any.

            run() will raise any raised exception after rollback.
            if rollback or commit fails, 
        """
        caught_exception = None
        confirm_result = None
        # commit_exception? By default, wee don't trap a confirm/commit exception, we'll just throw.
        execute_results = None
        
        # Executes operation and catches any exceptions
        try:
            execute_results = self.execute(*args,**kwargs)
        except Exception, e:
            # Stores exception in local variable for later use
            import sys # Need 'sys' to use actual exception, not rebased traceback
            caught_exception = sys.exc_info()

        # Confirm results            
        if not caught_exception:
            confirm_result = self.confirm()
        
        # Handle any errors or confirmation failure
        if caught_exception or not confirm_result:                
            # Attempt to rollback/cleanup operation
            try:
                self.cleanup_failure()
            except Exception, e:
                raise RollbackException("Encountered error, unable to cleanup on failure. Investigate current state of operation target.")
            if caught_exception:
                # Re-raise the original exception information
                raise caught_exception[1],None,caught_exception[2]
            else:
                # Raise local exception that confirmation failed
                raise ConfirmationException("Confirmation failed, operation rolled back.")
        else:
            self.cleanup_success()
            
        return execute_results
            

class AtomicOperationCollection(MutableSequence):
    """ Base class supporting the execution of an ordered chain of
        AtomicOperations and passing data between them.

        All chained operations must meet the AtomicOperation protocol:
         - execute() performs some action and will throw if it fails
         - confirm() checks the action behaved as expected, returning boolean
         - cleanup_fail() performs cleanup actions if the operation were to fail
         - cleanup_success() performs cleanup actions if the operation succeeds

        AtomicOperationCollection can operate like a list of AtomicOperations
        for purposes of messing with the chain or combining Collections.
    """
    
    def __init__(self,*args,**kwargs):
        self.ops_collection = [] # list of AtomicOperations
        self.results = [] # results of each stage
        self._cache = {} # k-v cache for chain
    
    # Local functionality
    
    def run(self,*args,**kwargs):
        exec_success = []
        exec_results = []
        caught_exception = None
        # Per-iteration arguments, set initially to args,kwargs from run call 
        op_args = args
        op_kwargs = kwargs
        # Run the sequence of AtomicOperations, but catch exceptions to allow rollback
        try:
            for i,op in enumerate(self.ops_collection):
                # Executes operation and catches any exceptions
                execute_results = None
                confirm_result = None
                try:
                    execute_results = op.execute(*opargs,**opkwargs)
                except Exception, e:
                    # Stores exception in local variable for later use
                    caught_exception = sys.exc_info()
                    
                if not caught_exception:
                    try:
                        confirm_result = op.confirm()
                    except Exception, e:
                        raise ConfirmationException("Failed when confirming step #%d, rolling back operations." % (i))
                
                if caught_exception or not confirm_result:
                    # Put a False on the exec_success outcomes list and stop processing
                    exec_success.append(False)
                    break
                
                else:
                    exec_success.append(True)
                    op_args,op_kwargs = op.chain_args # Get arguments for next step if available
                    exec_results.append(execute_results)
                
        except Exception, e:
            # Stores catch-all exception in local variable for later use (most likely ConfirmationException)
            caught_exception = sys.exc_info()
                
        # Handle irregular outcomes by rolling back
        if not all(exec_success) or len(exec_success) < len(self.ops_collection):
            # Attempt to rollback all performed operations since failure(s) occurred
            for i in xrange(len(exec_success),0):
                # Run through the operations backwards
                op = self.ops_collection[i]
                op.cleanup_failure()
            if caught_exception:
                # Re-raise the original failure
                raise caught_exception[1],None,caught_exception[2]
            else:
                # Just in case we have a surprise.
                raise AtomicOperationException("Unknown failure in running ops chain. Confirm state before proceeding.")

        # Handle normal execution
        for i in xrange(len(exec_success),0):
            op = self.ops_collection[i]
            op.cleanup_success()

        # Return results
        return exec_results

    # ABC overrides
    
    def __getitem__(self, index):
        return self.ops_collection.__getitem__(index)

    def __setitem__(self, index, value):
        self.ops_collecton.__setitem__(index,value)

    def __delitem__(self, index):
        self.ops_collecton.__delitem__(index)

    def __len__(self):
        return len(self.ops_collection)

    def insert(self, index, value):
        self.ops_collection.insert(index, value)

    def extend(self,iterable):
        self.ops_collection.extend(iterable)
    

# Exceptions for this module

class AtomicOperationException(Exception):
    """ Parent class for AtomicOperation errors."""
    pass

class RollbackException(AtomicOperationException):
    """ Used to signify an error in, or inability to, rollback an operation."""
    pass

class ConfirmationException(AtomicOperationException):
    """ Used to raise an error when confirmation fails on an atomic operation."""
    pass
