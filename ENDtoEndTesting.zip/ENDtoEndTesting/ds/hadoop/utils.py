""" Hadoop-specific utility methods for fsd2."""
from ..core.utils import get_environment,ENV_DEV,ENV_TEST,ENV_PROD,ENV_SAND,ENV_FAKEDEV
from ..core.shell import ShellCommand
import datetime
import subprocess
import random

def get_utc_timestamp():
    """ Returns a string in Hive's format representing the current UTC time."""
    return datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")

def get_hd_namenode():
    """ Retrieves the hostname of the Hadoop namenode."""
    thisenv = get_environment()
    if thisenv == ENV_PROD:
        return 'pwauslmnapp03.app.hcscint.net'
    elif thisenv == ENV_SAND:
        return 'sandbox.hortonworks.com'
    else:
        hd_process = ShellCommand(executable='hdfs',args=['getconf','-namenodes'],timeout=90)
        hd_output = hd_process.execute()
        # Random selection to balance across multiple NameNodes where appropriate
        return random.choice(hd_output.split())

ENV_DOMAINS = {
    ENV_DEV:'hive/_HOST@ADHCSCDEV.NET',
    ENV_FAKEDEV:'hive/_HOST@ADHCSCTST.NET',
    ENV_TEST:'hive/_HOST@ADHCSCTST.NET',
    ENV_PROD:'hive/_HOST@ADHCSCINT.NET',
    ENV_SAND:''
    }

# @TODO: Replace with config elements later
def get_kerb_principal():
    return ENV_DOMAINS[get_environment()]

HDFS_ENVS = {
    ENV_DEV:'dev',
    ENV_FAKEDEV:'dev',
    ENV_TEST:'test',
    ENV_PROD:'prod',
    ENV_SAND:'dev'
    }

def get_hdfs_env():
    return HDFS_ENVS[get_environment()]
