""" Static/literal values for use in FSD hadoop routines. """
