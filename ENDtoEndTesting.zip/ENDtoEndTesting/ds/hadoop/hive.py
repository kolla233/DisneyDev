from __future__ import unicode_literals

from utils import get_hd_namenode, get_kerb_principal
from ..core import BaseQuery,ShellCommand,LocalFile # relative import back to ds.core
from ..core.utils import get_environment,ENV_SAND
from ..logging import FsdLogger,getChild

import re
from itertools import izip,izip_longest,chain
from collections import OrderedDict,namedtuple
from uuid import uuid4
import datetime, csv

"""
    NOTE:   ds.hadoop.hive currently uses Beeline through the command shell
            to minimize dependencies and maintain 1:1 similarity to user-driven
            testing via the console.

            Devs should NOT assume Beeline will always be used going forward.
"""

# Set up Hive logger
hive_log = getChild(FsdLogger,'hadoop.hive')

class HiveQuery(BaseQuery):
    """ Defines a simple query for use against Apache Hive."""
    
    SIMULATE_MARKER = "SIMULATE REMOVE"
    
    # provides a mapping between outputformat -> major delimiter character
    DELIMITER_MAPPING = {   'tsv':'\t',
                            'tsv2':'\t',
                            'csv2':',',
                            'csv':',',
                            'dsv':'|' # may be overriden if the delimiter option provided
                        }
    
    def process_query(self,query,*args,**kwargs):
        """
            Removes newlines, tabs, repeated spaces from the query string.
            (can probably remove this in the future when not going via beeline)
        """
        # Split works on all whitespace when called with no args
        if not query:
            query = ""
        query_str = " ".join(query.split())
        return query_str
    
    def simulate_preprocessor(self,query_text):
        """ Removes all lines between lines containing SIMULATE_MARKER."""
        query_split = query_text.split('\n')
        hive_log.debug("Simulate preprocessor running on query (%d lines)." % (len(query_split)))
        # Generate numbered lines of the query, split by newlines
        query_lines = ((i,ln) for i,ln in enumerate(query_split))
        # Find the preprocessor marker lines in the text
        del_indices = [i for i,ln in query_lines if self.SIMULATE_MARKER in ln]
        # Fail if mismatched markers are found (they must be paired)
        if (len(del_indices) % 2):
            hive_log.error("Simulate preprocessor failed with mismatched %s markers. Markers must be balanced." %(self.SIMULATE_MARKER))
            raise ValueError("Query text has mismatched SIMULATE REMOVE lines.")
        # Generate lines to delete for each region
        iter_indices = iter(del_indices)
        del_lns = set(chain(*(xrange(a,b+1) for a,b in izip(iter_indices,iter_indices))))
        hive_log.debug("Simulate preprocessor found %d lines to remove in %d marked regions." % (len(del_lns),(len(del_indices)/2)))
        # Produce processed query text without the marked lines
        proc_query = '\n'.join(ln for i,ln in enumerate(query_split) if i not in del_lns)
        return proc_query
    
    def execute(self,*args,**kwargs):
        """ Executes the query through Beeline.
            Optional keyword arguments:
            timeout        None    time for query to run before throwing a CommandTimeoutException
            use_tez        True    whether Hive should use Tez (True) or MapReduce (False)
            use_stats      False   whether to use metastore table stats to answer simple queries
            simulate       False   whether to use the "SIMULATE REMOVE" pre-processor
            outputformat   tsv2    controls the beeline "outputformat" parameter (tsv2, dsv, etc.)
            headers        False   whether to include a header row
            file           ''      File path to execute HQL directly
            hiveconf       {}      dict of any extra hiveconf key-value pairs (will be prefixed with "--hiveconf")
            hivevar        {}       hivevar k=v dict
        """
        simulate = kwargs.get("simulate",False)
        b_args = []
        run_metadata = {} # Dictionary to store run args
        
        # Initial connection string
        b_args.append("-u")
        if get_environment() == ENV_SAND:
            b_args.append('"jdbc:hive2://localhost:10000/default"')
        else:
            b_args.append('"jdbc:hive2://%s:10001/;principal=%s;transportMode=http;httpPath=cliservice"' % (get_hd_namenode(), get_kerb_principal()))
        
        # Beeline parameters
        args_outputformat = kwargs.get('outputformat','tsv2')
        b_args.append("--outputformat=%s" % (args_outputformat))
        run_metadata['outputformat'] = args_outputformat
        
        args_headers = kwargs.get('headers',False)
        b_args.append("--showHeader=%s" % (unicode(args_headers).lower()))
        run_metadata['headers'] = args_headers
        
        # hiveconf parameters
        hiveconf = {}
        if kwargs.get('exec_engine') == 'mr':
            hiveconf['hive.execution.engine'] = 'mr'
        elif kwargs.get('exec_engine') == 'spark':
            hiveconf['hive.execution.engine'] = 'spark'
        else:
            hiveconf['hive.execution.engine'] = 'tez'
        hiveconf['hive.compute.query.using.stats'] = unicode(kwargs.get('use_stats',False)).lower()
        # override with any 'hiveconf' kwarg values
        hiveconf.update(kwargs.get('hiveconf',{}))
        run_metadata['hiveconf'] = hiveconf
        
        query_str = ""
        
        if 'file' in kwargs:
            file_arg = kwargs.get("file")
            # If we get a file path, we assume it's for LocalFile
            if isinstance(file_arg,basestring):
                file_arg = LocalFile(file_arg)
            # Process it assuming it's a BaseFile object now
            file_path = file_arg.path
            query_str = file_arg.read()
            hive_log.debug("Executing query from file '%s'" % (file_path))
        else:
            # actual query to execute
            query_str = self.query
            hive_log.debug("Executing query: %s" % (self.query))
        
        # hivevar
        hivevar = {}
        hivevar.update(kwargs.get('hivevar',{}))
        run_metadata['hivevar'] = hivevar
        
        # retain original query string retrieved from self or file
        run_metadata['query_orig'] = query_str
        
        if hivevar:
            hive_log.debug("Query hivevar values: %s" % (hivevar))
            hivevar_str = "\n".join([('SET hivevar:%s=%s;' % (k,v)) for k,v in hivevar.iteritems()])
            hive_log.debug("Hivevar section prepended to query: %s" % (hivevar_str))
            query_str = hivevar_str + " " + query_str
        
        if hiveconf:
            hive_log.debug("Query hiveconf values: %s" % (hiveconf))
            hiveconf_str = "\n".join([("SET %s=%s;" % (k,v)) for k,v in hiveconf.iteritems()])
            query_str = hiveconf_str + query_str
        
        if simulate:
            query_str = self.simulate_preprocessor(query_str)
        
        # retain processed query string
        run_metadata['query_final'] = query_str
        
        b_args.append("-e")            
        b_args.append('%s' % query_str)
        # check for timeout value
        query_timeout = kwargs.get('timeout',None)
        run_metadata['timeout'] = query_timeout
        # execute query
        run_metadata['run_start'] = datetime.datetime.utcnow()
        query_cmd = ShellCommand(executable='beeline',args=b_args,timeout=query_timeout)
        self.results = query_cmd.execute()
        run_metadata['run_finish'] = datetime.datetime.utcnow()
        self._results_metadata = run_metadata
        
    def process_results(self, results, *args, **kwargs):
        """ Processes the query results."""
        return results.rstrip("\n")
    
    def get_delimiter(self):
        """ Returns the delimiter used in query results."""
        if self.results:
            # get delimiter used by results
            run_format = self._results_metadata.get('outputformat',None)
            if not run_format:
                error_msg = "No outputformat was stored in run_metadata."
                hive_log.error(error_msg)
                raise KeyError(error_msg)
            
            # retrieve character for mapping
            run_delim = self.DELIMITER_MAPPING.get(run_format,None)
            if not run_delim:
                error_msg = "Output format ('%s') is not known to HiveQuery, no delimiter specified in DELIMITER_MAPPING (valid values: '%s')." % (run_format,','.join(DELIMITER_MAPPING.keys()))
                hive_log.error(error_msg)
                raise KeyError(error_msg)
            
            return run_delim
        else:
            return None
    
    def parse_row(self,row_text,delim=None,fieldtuple=None):
        """ Parses a row in the results, either to a tuple or namedtuple."""
        # get the delimiter if it's not an arg
        if not delim:
            delim = self.get_delimiter()
        # @TODO: make this handle (1) escaped chars and (2) [double] quoted chars
        row_res = tuple(v for v in row_text.split(delim))
        if fieldtuple:
            # check to ensure we're getting a namedtuple
            if not getattr(fieldtuple,'_fields',None):
                error_msg = "Argument 'fieldtuple' must be a namedtuple, received '%s' instead." % (str(fieldtuple))
                hive_log.error(error_msg)
                raise TypeError(error_msg)
            # cast the plain tuple to the fieldtuple class
            row_res = fieldtuple(*row_res)
        return row_res
    
    def __iter__(self):
        """ Iterates over the rows in the results."""
        iter_re = re.compile(""".*""") # simple regex to pull a line
        if self.results:
            delim = self.get_delimiter()
            headers = self.get_headers()
            rowiter = iter_re.finditer(self.results)
            fieldtuple = None
            if headers:
                fieldtuple = namedtuple('query_'+uuid4().hex,headers)
                rowiter.next()
            for row in rowiter:
                try:
                    yield self.parse_row(row.group(0),delim,fieldtuple)
                except TypeError, e:
                    continue
        else:
            raise StopIteration
    
    def get_headers(self):
        """ Returns iterable of query result headers 
            if headers=True was selected for .execute() ."""
        if self.results and self._results_metadata.get('headers',False):
            # process first (header) row from query results based on first newline in .results
            header_row = self.results[:self.results.index("\n") if "\n" in self.results else -1]
            # @TODO: need to handle quoted/escaped records!
            header_list = self.parse_row(header_row)
            header_list_alt = tuple(v.split(".")[-1] for v in header_list)
            if len(set(header_list_alt)) != len(header_list):
                header_list = tuple("_".join(v.split(".")) for v in header_list)
            else:
                header_list = header_list_alt
            return header_list
        else:
            # if there aren't any results or headers, return None
            return None
    
    def __len__(self):
        """ Returns the number of records returned by the query, less any header row."""
        if self.results:
            # count the number of newlines in the results data
            newline_count = self.results.count("\n") + 1 # you have N-1 newlines for N lines
            if self._results_metadata.get('headers',False):
                newline_count += -1
        else:
            newline_count = 0
        return newline_count
    
class HiveOperation(HiveQuery):
    """ Subclass of HiveQuery used for execution of
        simple fixed commands against Hive."""
    pass

class HiveOperationException(Exception):
    pass

class HiveTableInfo(HiveOperation):
    """ Retrieves and parses the configuration of a Hive table or view object."""

    TABLE_INFO_KEYS = ( ('columns','col_name')
                       ,('partitions','Partition Information') # partition information has a 2-line header
                       ,('info','Detailed Table Information')
                       ,('storage','Storage Information')
                       ,('view','View Information'))

    TABLE_KEY_DICT = dict((b,a) for a,b in TABLE_INFO_KEYS) # Use 2.6-compatible syntax
    
    TBLINFO_TIMEOUT = 60 * 5 # 5 minute timeout, it's DESCRIBE FORMATTED...
    
    def __init__(self,database,table):
        """ Configure query using 'database' and 'table' arguments."""
        self.raw_describe = None
        self.database = database
        self.table = table
        query = "DESCRIBE FORMATTED %s.%s;" % (database,table)
        super(HiveTableInfo, self).__init__(query=query)
        self.execute(timeout=self.TBLINFO_TIMEOUT)

    # Table metadata methods and properties
    
    @property
    def name(self):
        return "%s.%s" % (self.database,self.table)        

    @property
    def owner(self):
        """ Returns the value of the "Owner" of the object."""
        return self.results['info']['Owner']
    
    @property
    def columns(self):
        """ Returns a list of column names for the table."""
        return self.results['columns'].keys()

    @property
    def storage(self):
        """ Returns a descriptor of the storage type in use by the table."""
        return self.results['storage']['SerDe Library']
    
    @property
    def table_type(self):
        """ Returns the table type of the object."""
        return self.results['info']['Table Type']
    
    @property
    def is_view(self):
        """ Returns True if object is a view, False otherwise."""
        return self.table_type == "VIRTUAL_VIEW"

    @property
    def is_managed(self):
        """ Returns True if managed, False otherwise."""
        return self.table_type == "MANAGED_TABLE"            

    @property
    def is_external(self):
        """ Returns True if external, False otherwise."""
        return self.table_type == "EXTERNAL_TABLE"
    
    @property
    def partitioned(self):
        """ Returns True if partitioned, False otherwise."""
        return ("partitions" in self.results.keys())
    
    @property
    def path(self):
        """ Returns the HDFS path of the table's storage."""
        return self.results['info']['Location']

    # Override methods of the HiveOperation class
    
    def process_results(self,results,*args,**kwargs):
        """ Parses the output of the DESCRIBE FORMATTED command."""

        # Stash the raw results just in case
        self.raw_describe = results
        
        results_dict = {}
        
        # split the results into lines, omitting blank lines
        res = results.replace("NULL","")

        #res_hdr,res_ln = zip(*[(x.group(0).replace('#','').split('\t')[0].strip(),(x.start(),x.end())) for x in re.finditer("""(#.+(\n#.+)?)""",res)])
        describe_hdr_regex = re.compile("""(#.+(\n#.+)?)""")
        res_hdr = []
        res_ln = []
        
        for seg in describe_hdr_regex.finditer(res):
            # Iterates through segment headers in DESCRIBE FORMATTED results
            seg_start = seg.start() # character index in 'res' from SREMatch result
            seg_end = seg.end() # character index in 'res' from SREMatch result
            seg_hdr = seg.group(0).replace('#',"").split('\t')[0].strip()
            res_ln.append((seg_start,seg_end))
            res_hdr.append(seg_hdr)
        
        res_len = len(res)
        res_ln.append((res_len,res_len))

        segment_pairs = zip(list(chain(*res_ln))[1:-1:2],list(chain(*res_ln))[2:-1:2])
        res_split = [filter(lambda x: x.strip(),res[a:b].split('\n')) for a,b in segment_pairs]
        
        # creates sub-groups for each parameter section
        kv_splitter = re.compile("""\:(?![^{]*})""")
        param_ranges = [[i for i,v in enumerate(res_grp) if any(kv_splitter.finditer(v))] for res_grp in res_split]
        
        # Process into a results dictionary
        for i,hdr in enumerate(res_hdr):
            try:
                k = self.TABLE_KEY_DICT[hdr]
            except KeyError:
                print "Unknown header '%s' encountered, ignoring." % (hdr)
                continue
            if len(param_ranges[i]) == 0:
                # Process as TSV
                results_dict[k] = self.parse_tsv_lines(res_split[i])
            else:
                # Process as KV
                lines = self.split_list(res_split[i],param_ranges[i],include_marks=True,include_range=True)
                results_dict[k] = self.parse_kv_lines(lines)

        return results_dict

    # Utility methods

    @staticmethod
    def parse_tsv_lines(lines):
        """ Handles parsing of TSV type lines."""
        return OrderedDict(filter(lambda x: len(x)==2,([v.strip() for v in ln.split('\t')[:2]] for ln in lines)))

    def parse_kv_lines(self, lines):
        """ Handles parsing of KV type lines."""
        results_dict = OrderedDict()
        for ln,ln_range in lines:
            firstln = ln[0]
            # all key-values in :-separated stuff will have a first key line
            ln_key,ln_val = [v.strip() for v in re.split(""":(?:\s+)""",firstln)][0:2]
            if "view" in ln_key.lower():
                # Handle views differently
                ln_val = ln_val + "\n".join(ln[1:])
            elif (ln_range[1]-ln_range[0] > 1) and not ln_key.startswith("View"):
                ln_val = self.parse_tsv_lines(subln.strip() for subln in ln[1:])
            results_dict[ln_key] = ln_val
        return results_dict
    
    @staticmethod
    def split_list(to_split,marks,include_marks=False,include_range=False):
        """ Splits 'to_split' list into child lists at indices marked by 'marks'."""
        offset = 0
        if not include_marks:
            offset += 1
        split = [to_split[(x+offset):y] for (x,y) in izip_longest(marks,marks[1:],fillvalue=None)]
        if include_range:
            split = zip(split,[(x+offset,y if y else len(to_split)) for (x,y) in izip_longest(marks,marks[1:],fillvalue=None)])
        return split    

class HiveResetStats(HiveOperation):
    """ Resets the table statistics for a given Hive table object."""

    def __init__(self,database,table):
        """ Sets up query using 'database' and 'table' arguments."""
        self.database = database
        self.table = table
        query = "ANALYZE TABLE %s.%s COMPUTE STATISTICS;" % (database,table)
        super(HiveResetStats, self).__init__(query=query)

class HiveRenameTable(HiveOperation):
    """ Renames a given Hive table."""

    def __init__(self,database,old_name,new_name):
        self.database = database
        self.old_table = old_name
        self.new_table = new_name
        # @TODO: Sanitize inputs 'database','old_name','new_name'
        query = "USE %s; ALTER TABLE %s RENAME TO %s;" % (database,old_name,new_name)
        super(HiveRenameTable, self).__init__(query=query)
        

class HiveValuesWriter(HiveQuery):
    """ Provides the ability to write one or more lines to a Hive table."""
    
    HIVE_INSERT_VARS = ("{hive_db}","{hive_tbl}","{hive_data}")
    HIVE_INSERT_BASE = "INSERT INTO TABLE {hive_db}.{hive_tbl} VALUES {hive_data};"
    
    def __init__(self,hive_db,hive_tbl,*args,**kwargs):
        self._buffer = []
        self._tgt_db_name = hive_db
        self._tgt_tbl_name = hive_tbl
        
        self.default_blank = kwargs.get('blanks',"NULL") 
        
        self.tblinfo = HiveTableInfo(hive_db,hive_tbl)
        # Since we have the info already, throw if it's a view.
        if self.tblinfo.is_view:
            error_msg = "Cannot write to a Hive view object (%s)" % (hive_db+"."+hive_tbl)
            hive_log.error(error_msg)
            raise ValueError(error_msg)
        
        # Can customize the query used for INSERTing values if the same string variables are provided
        query_template = kwargs.get("query",self.HIVE_INSERT_BASE)
        if "query" in kwargs:
            hive_log.debug("Using custom query template: %s" % (query_template))
        
        super(HiveValuesWriter,self).__init__(query_template,*args,**kwargs)

    # Decorator to only override the 'getter' of the .query property
    @HiveQuery.query.getter
    def query(self):
        """ Overrides the '.query' property to fill in the template with buffer values."""
        vals = ", ".join("(%s)" % (', '.join(l.values())) for l in self._buffer)
        return self._query.format(hive_db=self._tgt_db_name,hive_tbl=self._tgt_tbl_name,hive_data=vals)
        
    def process_query(self,query,*args,**kwargs):
        """ Ensures that the template query string
            contains the correct substitution variables."""
        
        if not all([(v in query) for v in self.HIVE_INSERT_VARS]):
            error_msg = "INSERT template must provide %d string variables: %s." % (len(self.HIVE_INSERT_VARS),unicode(self.HIVE_INSERT_VARS))
            hive_log.error(error_msg)
            raise ValueError(error_msg)
        return query

    @property
    def fields(self):
        """ Convenience property that returns an OrderedDict of fields in the target table."""
        rtndict = OrderedDict([(v,None) for v in self.tblinfo.columns])
        return rtndict
    
    def clear_buffer(self):
        """ Clears the write buffer."""
        self._buffer = []

    def write(self,*args,**kwargs):
        """ Similar to a file.write() object, writes a row of values to the buffer.
            
            .write() accepts the following formats:
                .write(col1=A, col2=B, col3=C...)
                .write({'col1':A,'col2':B,'col3':C...})
                .write([A,B,C...])
                .write(A,B,C...)

            When specifying columns, it isn't necessary to provide
            every column in the .write() call.
            
            When not providing columns (sequences), it's necessary to provide
            a sequence of the same length as the number of columns in the target.
        """
        
        if kwargs:
            values = dict((unicode(k),v) for k,v in kwargs.iteritems())
        elif len(args)>0:
            if hasattr(args[0],'__iter__'):
                values = args[0]
            else:
                values=args
        else:
            error_msg = "Must provide values to write!"
            hive_log.error(error_msg)
            raise ValueError(error_msg)
        
        if not isinstance(values,dict):
            if len(values) != len(self.tblinfo.columns):
                error_msg = "If providing a sequence of values, must provide same number of values as fields. Received %d values for %d fields." % (len(values),len(self.tblinfo.columns))
                hive_log.error(error_msg)
                raise ValueError(error_msg)
            # Process the list of values assuming it's a sequence
            bufvals = OrderedDict(izip(self.tblinfo.columns,("'%s'" % (v) for v in values)))
        else:
            # Put into an OrderedDict (standard dicts are acceptable) and add to buffer
            bufvals = OrderedDict((col,"'%s'" % val) if val else (col,self.default_blank) for col,val in ((k,values.get(k,None)) for k in self.tblinfo.columns ))
        hive_log.debug("Writing to buffer: %s" % (bufvals))
        # Write values to internal buffer
        self._buffer.append(bufvals)

    def writelines(self,valuelines):
        """ Convenience method akin to file.writelines. """
        for ln in valuelines:
            self.write(ln)

    def __enter__(self):
        hive_log.debug("Entering context manager for %s" % (self.__class__.__name__))
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        hive_log.debug("Exiting context manager for %s" % (self.__class__.__name__))
        if not exc_type:
            self.execute()
            self.clear_buffer()

class HiveTableMigration(object):
    """ Provides a migration of a table with data in it
        to a new structure with the same name, using new DDL and
        provided mapping.

        If no mapping is provided, HTM will automatically map fields by
        their name and rearrange values as needed. Mappings need only provide a
        subset of fields, all remaining fields will be mapped by name or using
        a fill value.

        HiveTableMigration supports:
        a. SAME TABLE: adding/modifying columns or order
        b. DIFF TABLE: moving data to NEW table with different layout
        
        HiveTableMigration requires:
        - source database + table name
        - destination database + table name (may be same as source)
        - [optional] DDL for new table
        - [optional] field mapping
        - [optional] whether to drop source table (follows even with src==dest, leaves _OLD version)
        - [optional] fill value for unmapped field (default: NULL)

        What HiveTableMigration does:
        1. Retrieves table metadata for the source table
        2a.(if different dest. and DDL provided) Creates destination table
        2b.(if same table and DDL provided) Creates destination table with suffix "_NEW"
        3. (if different dest.) Retrieves table metadata for dest. table
        4. Generates mapping between SRC and DEST tables
        5. Creates SELECT statement for INSERT from SRC to DEST
        6. Runs INSERT from SRC to DEST
        *  atomic version will perform ACR here
        7. (if SRC==DEST) Renames SRC with suffix "_OLD"
        8. (if SRC==DEST) Renames DST without suffix "_NEW"
        9. (if drop source enabled) Drops SRC table

    """
    
    # @TODO: Create an AtomicHiveTableMigration using ACR and AtomicOperation
    
    # @TODO: Figure out how to handle partitioned tables, or fail if partitioned

    OLD_SUFFIX = "_OLD"
    NEW_SUFFIX = "_NEW"
    
    def __init__(self,src_db,src_table,dst_db,dst_table):
        raise NotImplementedError("This class has not been completed, please do not use in code.")
        # Required arguments
        self.src_db = src_db
        self.src_table = src_table
        self.dst_db = dst_db
        self.dst_table = dst_table
        
        # Optional arguments
        self.dst_ddl = kwargs.get("dst_ddl",None)
        self.mapping = kwargs.get("mapping",{})
        self.drop_src = kwargs.get("drop_src",True)

        # Internal setup
        self.src_temp = None # temp table name for source table (if used)
        self.dst_temp = None # temp table name for dest table (if used)

    def prep_tables(self):
        if self.dst_ddl:
            if self.same_table:
                # Move old source table out of the way
                src_rename = self.get_renametable(self.src_db,self.src_table,OLD_SUFFIX)
                src_rename.execute()
                self.src_temp = src_rename.new_name
            # Create new table
            # @TODO Catch exceptions here when issuing the DDL query
            ddl_query = HiveQuery(query=self.dst_ddl)
            ddl_query.execute()
            
        
    def execute(self,*args,**kwargs):
        # Retrieve source table metadata
        src_info = self.get_tableinfo(self.src_db,self.src_table)
        
    @property
    def same_table(self):
        """ Convenience method to check if the
            migration is back to the same object."""
        return (self.src_db==self.dst_db and self.src_table==self.dst_table)

    @staticmethod
    def get_renametable(database,table,suffix,add_suffix=True):
        """ Adds or removes suffix from table name
            and returns a HiveRenameTable object. """
        if add:
            # Adds the suffix
            new_name = table + suffix
        else:
            # Removes the suffix
            new_name = table[:-len(suffix)]
        rename_obj = HiveRenameTable(database,table,new_name)
        return rename_obj
    
    @staticmethod
    def get_tableinfo(database,table):
        """ Assembles a HiveTableInfo object for the requested combination."""
        return HiveTableInfo(database,table)
