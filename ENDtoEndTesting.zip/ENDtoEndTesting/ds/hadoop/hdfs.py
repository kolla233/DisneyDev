from __future__ import unicode_literals
from io import TextIOWrapper
from collections import namedtuple
import posixpath
import datetime

from ..core import BaseFile, BaseDirectory, ShellIO, ShellCommand, BaseFSException
from ..core.shell import ShellCommandException

# Set up HDFS logging
from ds.logging import getChild,FsdLogger,Stopwatch
hdfs_log = getChild(FsdLogger,"hadoop.hdfs")

class HDFSException(BaseFSException):
    """ Generic HDFS operation exception."""
    pass

def get_hdfs_object(path):
    """ Retrieves either a HDFSDirectory or HDFSFile for a given HDFS path
        as a tuple of ('f',HDFSFile()) or ('d',HDFSDirectory())."""
    hdfs_log.debug("Processing HDFS path '%s' into object." % (path))
    hdir = HDFSDirectory(path)
    hfile = HDFSFile(path)
    if ('*' in path) or hdir.exists:
        hdfs_log.debug("'%s' is a directory." % (path))
        return 'd',hdir
    elif hfile.exists:
        hdfs_log.debug("'%s' is a file." % (path))
        return 'f',hfile
    else:
        hdfs_log.error("'%s' is of an unknown type." % (path))
        raise HDFSException("Unknown object at path %s." % (path))

class HDFSFile(BaseFile):
    """ Represents a file on the Hadoop filesystem."""
    
    def __init__(self,path,*args,**kwargs):
        self._path = None
        self.path = path
        self._reader = None
        self._writer = None
        self._metadata = kwargs.get('metadata',None)
        self.owner = None
        self.timestamp = None
    
    @property
    def filename(self):
        return posixpath.basename(self.path)
    
    def __unicode__(self):
        """ Returns the path of the object."""
        return self.path
    
    def file_exists(self,path=None):
        """ Returns True if the file exists on HDFS, False otherwise."""
        if not path:
            path = self.path
        test_exists = ShellCommand(executable="hadoop",args=["fs","-test","-f",path],ignore_rtncode=True)
        test_exists.execute()
        # If rtncode is non-zero
        if test_exists.rtncode:
            return False
        else:
            return True
    
    def get_metadata(self):
        """ Gets relevant metadata on the object if the file exists."""
        try:
            # Stores the LS_PROPS value for the file
            self._metadata = HDFSDirectory(self.path).list_contents()[0]
        except (ShellCommandException,IndexError):
            hdfs_log.debug("Metadata cannot be retrieved for %s at '%s' - path not found." % (self.__class__.__name__,self.path))
    
    def set_metadata(self):
        """ Sets up the relevant metadata for the object."""
        self.timestamp = datetime.datetime.strptime("%s %s" % (self._metadata.mod_date,self._metadata.mod_time),"%Y-%m-%d %H:%M")
        
    def get_reader(self):
        """ Returns a file-like object for reading from the HDFS file."""
        reader_io = ShellIO(executable="hadoop",args=["fs","-cat",self.path])
        rd_none,rd_stdout,rd_stderr = reader_io.open_io()
        return rd_stdout
    
    def get_writer(self,mode='w'):
        """ Returns a file-like object for writing to the HDFS file.
            Mode is either 'w' for overwrites, or 'a' for appends.
        """
        if mode == 'w':
            write_command = "-put"
        elif mode == 'a':
            write_command = "-appendToFile"
        else:
            raise ValueError("Invalid file mode '%s' provided - valid modes are 'w' and 'a'." % (mode))
        writer_io = ShellIO(executable="hadoop",args=["fs",write_command,"-",self.path])
        wr_stdin,wr_stdout,wr_stderr = writer_io.open_io(stdin=True,stdout=True,stderr=True)
        return wr_stdin
    
    def process_path(self,path_str):
        """ Strips any quoting off of the path string provided."""
        return path_str.strip(""" "'`""")
        
    def copy(self,dest_path,overwrite=False):
        """ Makes a copy of the file at 'dest_path'."""
        hdfs_log.info("Copying file '%s' to '%s'" % (self.path,dest_path))
        args_list = ["fs","-cp",self.path,dest_path]
        if overwrite:
            args_list.insert(2,"-f")
        copy_cmd = ShellCommand(executable="hadoop",args=args_list)
        copy_cmd.execute()

    def toLocal(self, dest_path):
        """ Makes a copy of the file at 'dest_path'."""
        hdfs_log.info("Copying file '%s' to '%s'" % (self.path, dest_path))
        args_list = ["fs", "-copyToLocal", self.path, dest_path]
        copy_cmd = ShellCommand(executable="hadoop", args=args_list)
        copy_cmd.execute()

    def MergeFilesToOneFile(self, dest_path):
        """ Makes a copy of the file at 'dest_path'."""
        hdfs_log.info("Copying file '%s' to '%s'" % (self.path, dest_path))
        args_list = ["fs", "-getmerge", self.path, dest_path]
        copy_cmd = ShellCommand(executable="hadoop", args=args_list)
        copy_cmd.execute()

    def move(self,dest_path):
        """ Moves the file to 'dest_path'."""
        hdfs_log.info("Moving file '%s' to '%s'" % (self.path,dest_path))
        mv_cmd = ShellCommand(executable="hadoop",args=["fs","-mv",self.path,dest_path])
        mv_cmd.execute()
        if self.file_exists(dest_path):
            self.path = dest_path
        else:
            error_msg = "Move to '%s' failed, destination file does not exist." % (dest_path)
            hdfs_log.error(error_msg)
            raise HDFSException(error_msg)

    def delete(self):
        """ Deletes the underlying file and clears self.path."""
        hdfs_log.info("Deleting file '%s'" % (self.path))
        del_cmd = ShellCommand(executable="hadoop",args=["fs","-rm",self.path])
        del_cmd.execute()
        self._writer = None
        self._reader = None

    def create(self,contents=None):
        """ Creates a 0-byte file with the specified path, or writes 'contents' into a new file."""
        if contents:
            with self.get_writer() as w:
                w.write(contents.read())
        else:
            hdfs_log.info("Creating file '%s'" % (self.path))
            t_cmd = ShellCommand(executable="hadoop",args=["fs","-touchz",self.path])
            t_cmd.execute()
    
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        objpath,objname = self.path.rsplit("/",1)
        newpath = self.path[:len(objpath)+1] + new_name
        self.move(newpath)
    
    def get_checksum(self):
        """ Returns the HDFS checksum of the file."""
        len_cmd = ShellCommand(executable="hadoop",args=["fs","-checksum",self.path])
        len_cmd.execute()
        return len_cmd.output.split()[-1]
    
    def size_bytes(self):
        """ Runs the HDFS -du command to get file size on disk."""
        len_cmd = ShellCommand(executable="hadoop",args=["fs","-du",self.path])
        len_cmd.execute()
        lenval = len_cmd.output.split(' ',1)
        if lenval:
            lenval = int(lenval[0])
        else:
            lenval = 0
        return lenval

class HDFSDirectory(BaseDirectory):
    # Normal response from hadoop ls:
    # permissions number_of_replicas userid groupid filesize modification_date modification_time path
    LS_PROPS = namedtuple('ls_props',('dir','permissions','replicas','userid','groupid','filesize','mod_date','mod_time','path'))
    # dir_count file_count content_size (bytes) pathname
    CNT_PROPS = namedtuple('cnt_props',('dir_count','file_count','size','path'))
    
    def __init__(self,path,*args,**kwargs):
        """ Represents a directory on the Hadoop filesystem."""
        self._path = None # HDFS path including filter
        self._dirpath = None # HDFS path of the actual directory
        self._metadata = kwargs.get('metadata',None) # Placeholder for LS_PROPS for the directory
        self.path = path
        
    @staticmethod
    def is_dir(permissions):
        """ Takes the permission string from LS and returns True if it's a directory entry."""
        if permissions[0].lower() == 'd':
            return True
        else:
            return False
    
    def iter_objects(self,filelist):
        """ Given an iterable of LS_PROPS tuples, returns a generator of objects."""
        return (HDFSDirectory(x.path,metadata=x) if x.dir else HDFSFile(x.path,metadata=x) for x in filelist)
    
    def dir_exists(self,path=None):
        """ Returns True if the file exists on HDFS, False otherwise."""
        if not path:
            path = self._dirpath
        test_exists = ShellCommand(executable="hadoop",args=["fs","-test","-d",path],ignore_rtncode=True)
        test_exists.execute(return_output=False)
        if test_exists.rtncode:
            return False
        else:
            return True
    
    def process_path(self,path_str):
        """ Strips any quoting off of the path string provided."""
        cleanpath = path_str.strip(""" "'`""").rstrip("/")
        self._dirpath = cleanpath
        if '*' in cleanpath:
            parts = cleanpath.rsplit('/',1)
            if '*' in parts[0]:
                raise ValueError("Wildcard ('*') must be in the last part of the HDFS path.")
            self._dirpath = parts[0]
        return cleanpath
    
    @property
    def filtered(self):
        """ Returns True if the HDFSDirectory object has a wildcard filter on it."""
        return self._path != self._dirpath
        
    def list_contents(self,dirs=True,files=True,recursive=False):
        """ Returns the formatted version of 'hdfs dfs -ls PATH'"""
        ls_args = ["fs","-ls",self.path]
        if '*' in self.path:
            ls_args.insert(2,"-d")
        if recursive:
            # Add the 'R'ecursive flag for hadoop fs -ls
            ls_args.insert(2,"-R")
        ls_cmd = ShellCommand(executable="hadoop",args=ls_args,ignore_rtncode=True)
        ls_cmd.execute()
        hdfs_log.debug("Received information about '%s': %s" % (self.path,ls_cmd.output))
        ls_output = filter(lambda x: x,[ln.split() for ln in ls_cmd.output.split("\n")[1:]])
        contents_list = []
        for ln in ls_cmd.output.split("\n"):
            try:
                p = ln.split()
                contents_list.append(self.LS_PROPS(self.is_dir(p[0]),*p))
            except (TypeError,IndexError):
                continue
        contents_list = filter(lambda prop: (prop.dir if dirs else False) or (not prop.dir if files else False),contents_list)
        return contents_list

    def create(self):
        """ Creates the directory at self.path."""
        hdfs_log.info("Creating directory '%s'" % (self._dirpath))
        mk_cmd = ShellCommand(executable="hadoop",args=["fs","-mkdir","-p",self._dirpath])
        mk_cmd.execute()
    
    def rename(self,new_name):
        """ Renames the object with new object name 'new_name'."""
        objpath,objname = self.path.rsplit("/",1)
        newpath = self.path[:len(objpath)+1] + new_name
        self.move(newpath)
    
    def copy(self,dest_path,overwrite=False):
        """ Makes a copy of the directory at 'dest_path'."""
        hdfs_log.info("Copying directory '%s' to '%s'" % (self._dirpath,dest_path))
        args_list = ["fs","-cp",self._dirpath,dest_path]
        if overwrite:
            args_list.insert(2,"-f")
        copy_cmd = ShellCommand(executable="hadoop",args=args_list)
        copy_cmd.execute()
        
    def copy_contents(self,dest_path):
        """ Moves only the contents of the folder."""
        hdfs_log.info("Copying contents from directory '%s' to '%s'" % (self.path,dest_path))
        files_list = self.files
        if files_list:
            copy_args = ["fs","-cp"] + [f.path for f in files_list] + [dest_path]
            cp_cmd = ShellCommand(executable="hadoop",args=copy_args)
            cp_cmd.execute()
        else:
            hdfs_log.info("Path '%s' was empty, nothing copied." % (self.path))
        
    def move(self,dest_path,overwrite=False):
        """ Moves the directory and contents to 'dest_path'."""
        dest_dir = HDFSDirectory(dest_path)
        hdfs_log.info("Moving directory '%s' to '%s'" % (self._dirpath,dest_path))
        if dest_dir.exists:
            if overwrite:
                dest_dir.delete(recursive=True)
            else:
                hdfs_log.error("Moving directory '%s' failed. Directory '%s' already exists, overwrite not specified." % (self._dirpath,dest_path))
                raise HDFSException("Move failed, destination folder already exists.")
        mv_cmd = ShellCommand(executable="hadoop",args=["fs","-mv",self._dirpath,dest_path])
        mv_cmd.execute()
        if self.dir_exists(dest_path):
            self.path = dest_path
        else:
            error_msg = "Move to '%s' failed, destination directory does not exist." % (dest_path)
            hdfs_log.error(error_msg)
            raise HDFSException(error_msg)

    def move_contents(self,dest_path):
        """ Moves only the contents of the folder."""
        hdfs_log.info("Moving contents from directory '%s' to '%s'" % (self.path,dest_path))
        files_list = self.files
        if files_list:
            move_args = ["fs","-mv"] + [f.path for f in files_list] + [dest_path]
            mv_cmd = ShellCommand(executable="hadoop",args=move_args)
            mv_cmd.execute()
        else:
            hdfs_log.info("Path '%s' was empty, nothing moved." % (self.path))            

    def delete(self,recursive=False):
        """ Deletes the underlying file and clears self.path."""
        hdfs_log.info("Deleting directory '%s'" % (self._dirpath))
        del_args = ["fs",self._dirpath]
        if recursive:
            del_args.insert(1,"-R")
            del_args.insert(1,"-rm")
        else:
            del_args.insert(1,"-rmdir")
        del_cmd = ShellCommand(executable="hadoop",args=del_args)
        del_cmd.execute()
    
    def clear(self,recursive=False):
        """ Clears contents from directory. """
        clear_path = self.path
        if '*' not in self.path:
            clear_path = self.path + "/*"
        hdfs_log.info("Clearing contents of directory '%s'" % (self.path))
        clr_args = ["fs","-rm",clear_path]
        if recursive:
            clr_args.insert(2,"-R")
        clr_cmd = ShellCommand(executable="hadoop",args=clr_args)
        clr_cmd.execute()
        
    def size_bytes(self):
        """ Runs the HDFS -du command to get file size on disk."""
        len_cmd = ShellCommand(executable="hadoop",args=["fs","-du","-s",self._dirpath])
        len_cmd.execute()
        lenval = len_cmd.output.split(' ',1)
        if lenval:
            lenval = int(lenval[0])
        else:
            lenval = 0
        return lenval        

    def MergeFilesToOneFile(self, dest_path):
        """ Makes a copy of the file at 'dest_path'."""
        hdfs_log.info("Copying file '%s' to '%s'" % (self.path, dest_path))
        args_list = ["fs", "-getmerge", self.path, dest_path]
        copy_cmd = ShellCommand(executable="hadoop", args=args_list)
        copy_cmd.execute()    