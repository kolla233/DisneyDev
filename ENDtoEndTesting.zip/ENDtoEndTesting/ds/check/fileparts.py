from __future__ import unicode_literals

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.filepart")

from basepart import CheckPartRegistry,BaseCheckPart

# for files (leveraging basefile)

class FileCheckPart(BaseCheckPart):
    """ Type of CheckPart for use with filesystem (HDFS, local FS) resources. Based on fsdlib BaseFile."""
    
    __platform__ = "file"

class FileCountPart(FileCheckPart):
    
    __checks__ = ("cnt","count")