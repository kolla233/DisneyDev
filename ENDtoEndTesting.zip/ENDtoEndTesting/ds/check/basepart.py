from __future__ import unicode_literals

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.part")

class CheckPartRegistry(object):
    """ Simple registry class for CheckParts."""
    
    REGISTRY = {}
    
    @classmethod
    def register(cls,checkpartcls):
        """ Decorator for registering CheckPart classes."""
        # add checkpartcls to the FSD_CHECKERS registration dict by its platform and 
        cls.REGISTRY[checkpartcls.__platform__.lower(),checkpartcls.__checks__[0].lower()] = checkpartcls
        return checkpartcls
    
    @classmethod
    def get_part(cls,platform,chktype):
        platform = platform.lower()
        chktype = chktype.lower()
        platforms,chktypes = zip(*cls.REGISTRY.keys())
        if platform not in platforms:
            raise UnsupportedCheckPlatform("Platform specified '%s' is not supported currently (supported platforms: %s)" % (platform,",".join(platforms)))
        if chktype not in chktypes:
            raise InvalidCheckError("Check type '%s' is not a supported check (supported checks across all platforms: %s)" % (chktype,",".join(chktypes)))
        try:
            rtnchk = cls.REGISTRY[platform,chktype]
            return rtnchk
        except KeyError:
            raise InvalidCheckError("Check type '%s' is not valid for platform '%s', please verify configuration." % (chktype,platform))

class BaseCheckPart(object):
    """ Base component for performing a 'check' against a resource. Responsible for 
        all preparation and execution against the resource and returning a list of Decimal
        objects for comparison."""
    
    __platform__ = None
    __checks__ = None
    
    def __init__(self,*args,**kwargs):
        self.results = []
    
    def execute(self,*args,**kwargs):
        raise NotImplementedError