from __future__ import unicode_literals

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.checker")

from exceptions import InvalidCheckError,UnsupportedFrameworkError

class CheckerRegistry(object):
    """ Simple registration class for Checkers."""
    
    REGISTRY = {}
    
    @classmethod
    def register(cls,checkercls):
        """ Registers a Checker class for a specific framework."""
        # add checkercls to the FSD_CHECKERS registration dict by its framework short-code
        cls.REGISTRY[checkercls.__framework__] = checkercls
        return checkercls
    
    @classmethod
    def get_checker(cls,framework):
        """ Returns a Checker class for the requested framework ID."""
        try:
            return cls.REGISTRY[framework]
        except KeyError:
            raise UnsupportedFrameworkError("No Checker found for framework '%s'." % (framework))
    

class BaseChecker(object):
    """ Base class for Checkers, implemented per execution 
        framework (fsdlib native, audit framework).
        
        Checkers implement an optional (no-op if not used) .prepare() method to 
        do any pre-work, and then an .execute() method to run the validation.
    """
    
    __framework__ = None # short-code for execution framework
    __frameworkdesc__ = None # long format description for execution framework
    
    def __init__(self,*args,**kwargs):
        # checkparts
        self.left = []
        self.right = []
    
    def prepare(self,*args,**kwargs):
        raise NotImplementedError
    
    def execute(self,*args,**kwargs):
        raise NotImplementedError
    

