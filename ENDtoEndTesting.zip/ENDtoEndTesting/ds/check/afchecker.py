from __future__ import unicode_literals

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.afchecker")

from ds.core.localfs import LocalFile
from ds.core.shell import ShellCommand

from basechecker import CheckerRegistry
from fsdchecker import FsdChecker
from exceptions import CheckerConfigError

# all fields present in the AF CSV
AF_CONFIG_FIELDS = ["src_sys_nm",
                    "src_rec_typ_nm",
                    "tgt_sys_nm",
                    "tgt_rec_typ_nm",
                    "proc_nm",
                    "pasv_aud_typ_nm",
                    "proc_typ_nm",
                    "fld_ctl_calc_mthd_nm",
                    "mismtch_thrhd_pct",
                    "pasv_aud_typ_rul_num",
                    "pasv_aud_typ_vrsn_num",
                    "proc_desc",
                    "src_rec_typ_desc",
                    "tgt_rec_typ_desc",
                    "src_sbjct_area_nm",
                    "tgt_sbjct_area_nm",
                    "src_fld_typ_pred_txt",
                    "src_fld_typ_rul_nm",
                    "src_schma_file_nm",
                    "src_sys_typ_nm",
                    "tgt_sys_typ_nm",
                    "targ_fld_typ_pred_txt",
                    "targ_fld_typ_rul_nm",
                    "targ_schma_file_nm",
                    "exclsn_rul_nm",
                    "inclusn_rul_nm",
                    "file_nm_pttrn_txt",
                    "Contact_Email_Address",
                    "SRC_FILE_DLMTR_TXT",
                    "TGT_FILE_DLMTR_TXT",
                    "SRC_FILE_HDR_TRL",
                    "TGT_FILE_HDR_TGT",
                    "SRC_FIX_POS",
                    "TGT_FIX_POS",
                    "RDBMS_NM",
                    "DB_NAME",
                    "DB_Username",
                    "Passwd_File_Path",
                    "QUERY_FILE_PATH",
                    "CONN_DETAILS",
                    "portfolio_name",
                    "where_clause_txt" ]

AF_FIXED_FIELDS = { "fld_ctl_calc_mthd_nm":"STOP",
                    "mismtch_thrhd_pct":"0",
                    "pasv_aud_typ_rul_num":"Y",
                    "targ_fld_typ_pred_txt":"Y",
                    "Contact_Email_Address":"Finance_Info_Deliv@domino.hcsc.net",
                    "portfolio_name":"FSD"
                    }

AF_HQL_DEST = "/tmp/fsdtmp/afdest/"
AF_CFG_DEST = "/tmp/fsdtmp/afdest/"
AF_CFG_NAME = "passive_smith_audit.csv"

from ds.core.utils import get_fs_env,get_current_user
EDGE_ENV = get_fs_env()
AUD_FWK_SH = "/datalakebin/%s/audit/ingestion/src/scripts/PASSIVE_AUDIT_CONFIG_FILE_READ.sh" % (EDGE_ENV)
AUD_FWK_EDGE = "/datalakedata/%s/fsd/consumption/work/acr/" % (EDGE_ENV)
AUD_FWK_HDFS = "/user/%s/" % (get_current_user())

@CheckerRegistry.register
class AfChecker(FsdChecker):
    """ Checker using 'Audit Framework' shell scripts for executing checks. Takes
        the same arguments as FsdChecker.
        
        When using the 'Audit Framework' scripts, run AfChecker.prepare(), then
        apply the generated configuration manually, and run AfChecker.execute()
    """
    
    __framework__ = 'af'
    __frameworkdesc__ = '"Audit Framework" shell script execution framework.'
    
    filenamevar = "{filename}"
    
    def get_hql_filename(self,layer,chk):
        filenm_str = AF_HQL_DEST+"FSD_AUTO_{flow_id}_{left_layer}{right_layer}_{layer}_{check}".format(flow_id=self.flow_id,left_layer=self.left_layer,right_layer=self.right_layer,layer=layer,check=chk).upper()+".hql"
        return filenm_str
    
    def get_conf_filename(self):
        path_str = AF_CFG_DEST+AF_CFG_NAME
        return path_str
    
    def get_conf(self):
        return LocalFile(self.get_conf_filename())

    def write_conf_header(self):
        conf_file = self.get_conf()
        with conf_file.get_writer(mode='w') as w:
            w.write(",".join(AF_CONFIG_FIELDS)+"\n")
    
    def get_filenm_txt(self):
        """ Returns a value for random field 'file_nm_pttrn_txt'..."""
        val_str = "FSD_AUTO_{flow_id}_{left}_{right}_{checks}".format(flow_id=self.flow_id,left=self.left_layer.upper(),right=self.right_layer.upper(),checks="_".join(v.upper() for v in self.get_checks())).upper()
        return val_str
    
    def get_proc_name(self):
        """ Returns the proc name for use by Audit Framework."""
        proc_str = "FSD_AUTO_{flow_id}_{left}_{right}_PASSIVE_AUDIT".format(flow_id=self.flow_id,left=self.left_layer.upper(),right=self.right_layer.upper()).upper()
        return proc_str
    
    def gen_csv_line(self,field_dict):
        """ Generates an ordered list of the values required for the config CSV."""
        output_vals = []
        for f in AF_CONFIG_FIELDS:
            foundval = field_dict.get(f,None)
            if not foundval:
                foundval = ""
            output_vals.append(foundval)
        return output_vals
    
    def prepare(self,*args,**kwargs):
        """ Runs prep steps for the Checker, which means:
            1. collecting all values needed for the config CSV
            2. generating the HQL files
        """
        checks = self.get_checks() # gets 'cnt','amt',etc.
        
        # sets up the CSV line to write
        af_dict = dict((k,None) for k in AF_CONFIG_FIELDS)
        
        # adds the fixed values
        for k,v in AF_FIXED_FIELDS.iteritems():
            af_dict[k] = v
        
        left_platform = [part.__platform__ for part in self.left][0].upper()
        right_platform = [part.__platform__ for part in self.right][0].upper()
        # fields calling for platform name(s) - 'HIVE'
        af_dict['src_rec_typ_nm'] = left_platform
        af_dict['tgt_rec_typ_nm'] = right_platform
        af_dict['src_sys_typ_nm'] = left_platform
        af_dict['tgt_sys_typ_nm'] = right_platform
        
        # fields calling for layer names - 'INCOMING','SMITHRAW'
        af_dict['src_sys_nm'] = self.left_layer.upper()
        af_dict['tgt_sys_nm'] = self.right_layer.upper()
        
        # proc nm
        af_dict['proc_nm'] = self.get_proc_name()
        af_dict['proc_typ_nm'] = "FSD_PSSV_AUDIT_" + "_".join(checks).upper()
        
        # audit check list
        chk_names = [part.__checks__[1] for part in self.left]
        af_dict['pasv_aud_typ_nm'] = "|".join(chk_names).upper()
        
        # left and right column lists
        left_cols = []
        for part in self.left:
            cols = getattr(part,'target_cols',[])
            if cols and cols != ['*']:
                left_cols = cols
        
        right_cols = []
        for part in self.right:
            cols = getattr(part,'target_cols',[])
            if cols and cols != ['*']:
                right_cols = cols
        
        af_dict['src_rec_typ_desc'] = "|".join(left_cols)
        af_dict['tgt_rec_typ_desc'] = "|".join(right_cols)
        
        # left and right HQL substitution variables
        where_left = [p.FILE_VAR for p in self.left if p.chkfile][:1]
        where_right = [p.FILE_VAR for p in self.right if p.chkfile][:1]
        af_dict['where_clause_txt'] = "&".join(where_left+where_right)
        
        # left and right HQL filenames
        left_paths = []
        for part in self.left:
            hql_str = part.build_query()
            hql_filename = self.get_hql_filename(self.left_layer,part.__checks__[0])
            hql_file = LocalFile(hql_filename)
            with hql_file.get_writer() as hql_writer:
                hql_writer.write(hql_str)
            left_paths.append(hql_filename)
        af_dict['src_fld_typ_rul_nm'] = "|".join(left_paths)
        
        right_paths = []
        for part in self.right:
            hql_str = part.build_query()
            hql_filename = self.get_hql_filename(self.right_layer,part.__checks__[0])
            hql_file = LocalFile(hql_filename)
            with hql_file.get_writer() as hql_writer:
                hql_writer.write(hql_str)
            right_paths.append(hql_filename)
        af_dict['targ_fld_typ_rul_nm'] = "|".join(right_paths)
        
        af_dict['file_nm_pttrn_txt'] = self.get_filenm_txt()
        
        csv_ln = self.gen_csv_line(af_dict)
        conf_file = self.get_conf()
        with conf_file.writer as w:
            w.write(",".join(csv_ln)+"\n")
    
    def execute(self,*args,**kwargs):
        """ Runs the AF shell scripts to execute the job defined in this Checker."""
        af_proc_nm = self.get_proc_name()
        af_pttn_nm = self.get_filenm_txt()
        where_param = self.filename + "&" + self.filename
        af_runner_args = [AUD_FWK_SH,af_proc_nm,af_pttn_nm,"",AUD_FWK_HDFS,AUD_FWK_EDGE,"","",where_param]
        checklog.debug("%s executing with following args: %s" % (self.__class__.__name__,af_runner_args))
        sc = ShellCommand(executable='ksh',args=af_runner_args,timeout=86400)
        sc.execute()
        
        