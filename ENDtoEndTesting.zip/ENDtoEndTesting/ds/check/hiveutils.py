from __future__ import unicode_literals

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.utils")

""" Utility module for ds.check.hiveparts"""
from decimal import Decimal
from ds.hadoop.hive import HiveQuery

class HiveValidationQuery(HiveQuery):
    """ Explicitly expects a single row to come back with numbers only."""

    def process_results(self,results,*args,**kwargs):
        """ Processes a potential list of numeric columns from results."""
        print results
        query_results = [Decimal(val) for val in results.split()]
        return query_results

class HiveFieldWrapper(object):
    """ Base implementation for a 'field wrapper' for use with Hive query strings."""
    
    wrappers = {}
    field = "wrapfield"
    
    def __init__(self,wrappername,wrapperstr,*args,**kwargs):
        self.name = wrappername
        self.fmtstr = wrapperstr
        self.wrappers[self.name] = self # registers the instance
    
    def wrap(self,fieldstr):
        """ Performs the wrapper's substitution on 'fieldstr'."""
        return self.fmtstr.format(**{self.field:fieldstr})

# for summation
HiveFieldWrapper("sum","SUM({%s})" % (HiveFieldWrapper.field))
# for absolute values
HiveFieldWrapper("abs","ABS({%s})" % (HiveFieldWrapper.field))
# for counting
HiveFieldWrapper("cnt","COUNT({%s})" % (HiveFieldWrapper.field))
# for coalescing NULL values
HiveFieldWrapper("coalesce","COALESCE({%s},0.00)" % (HiveFieldWrapper.field))
# for casting to decimal(13,4)
HiveFieldWrapper("cast","CAST({%s} AS DECIMAL(13,4))" % (HiveFieldWrapper.field))
# for standardizing accounting format...this one's kind of crazy, might be simplifiable?
HiveFieldWrapper("acctfmt","case when substr({fieldsub},1,1) = '(' then -(REGEXP_REPLACE({fieldsub},'[($)]','')) else REGEXP_REPLACE({fieldsub},'[$]','') end".format(fieldsub="{%s}" % HiveFieldWrapper.field))
