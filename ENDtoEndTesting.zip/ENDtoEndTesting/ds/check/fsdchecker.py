from __future__ import unicode_literals

import re

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.fsdchecker")

from basechecker import CheckerRegistry,BaseChecker
from basepart import CheckPartRegistry
from exceptions import CheckerConfigError

from ds.core.configmgr import get_flow_id,parse_list,parse_bool,ConfigManager

CONFIG_PREFIX = "aud_fwk_"
CONFIG_PREFIX_LEN = len(CONFIG_PREFIX)

CONFIG_CHKTYP = "af_chk"
CONFIG_LEFT = "src_"
CONFIG_RIGHT = "tgt_"

MULTICONF_PREFIX = re.compile("""^(\d+_).*""")

@CheckerRegistry.register
class FsdChecker(BaseChecker):
    """ Checker using FSD native library for executing checks."""
    
    __framework__ = 'fsd'
    __frameworkdesc__ = 'Native fsdlib execution framework.'

    @property
    def cm_section(self):
        if self._ovr_section:
            return self._ovr_section
        else:
            return "{prefix}{left}_{right}".format(prefix=CONFIG_PREFIX,left=self.left_layer,right=self.right_layer)
    
    def __init__(self,*args,**kwargs):
        """ FsdChecker expects the following as init args:
            - 'filename' OR 'flow' (CM flow id)
              (if using child classes that call .prepare, often flow will be provided for prepare, but filename for execution)
            - [optional] ConfigManager instance providing the flow configs and aud_fwk sections
            - [optional] aud_fwk section to use (in case of nonstandard or multiple config sections)
            - left_layer, corresponding to a flow_<leftlayer> and aud_fwk_<leftlayer>_<rightlayer>
            - right_layer, corresponding to a flow_<rightlayer> and aud_fwk_<leftlayer>_<rightlayer>
        """
        super(FsdChecker,self).__init__(self,*args,**kwargs) # sets up .left and .right lists
        # CM lookup parameters
        self.filename = kwargs.get("filename",None)
        self.flow_id = kwargs.get("flow",get_flow_id(self.filename))
        self.cm = kwargs.get("cm_obj",ConfigManager(flow=self.flow_id))
        # config parameters for this Checker
        self._ovr_section = kwargs.get("section",None) # override section (when multiple checks on one transition)
        self.left_layer = kwargs.get("left_layer","").lower()
        self.right_layer = kwargs.get("right_layer","").lower()
        if not self.left_layer or not self.right_layer:
            raise CheckerConfigError("Both 'left_layer' and 'right_layer' must be provided as keyword arguments to %s." % (self.__class__.__name__))
        # + with left and right layers, we know the config details and identify this Checker uniquely
        self.left,self.right = self.get_parts()
    
    def execute(self,*args,**kwargs):
        """ Runs the contained CheckParts and returns the results."""
        # executes all parts
        for part in self.left:
            part.execute()
        for part in self.right:
            part.execute()
        left_res = dict((part.__checks__,part.results) for part in self.left)
        right_res = dict((part.__checks__,part.results) for part in self.right)
        all_keys = set(left_res.iterkeys()).union(set(right_res.iterkeys()))
        rtn_dict = {}
        for k in all_keys:
            try:
                rtn_dict[k] = left_res[k] and right_res[k]
            except KeyError:
                # add a log message here
                rtn_dict[k] = None
        return rtn_dict
    
    @classmethod
    def get_sections(cls,cmobj,left=None,right=None):
        """ Returns section names, with flows split out, for a given CM object.
            May return duplicate sections in cases like:
                [aud_fwk_incoming_smith_0]
                [aud_fwk_incoming_smith_1]
            Which would be expected behavior when more than one Check call is required for a transition.
            [optional args]
            > left, the left layer to look for
            > right, the right layer to look for
        """
        cmsections = cmobj.sections # list all sections from the resolved CM object
        all_af_sections = [s for s in cmsections if s.startswith(CONFIG_PREFIX)]
        conf_af_sections = [] # 3-tuples of (section name, left flow, right flow) split out already
        for sect in all_af_sections:
            sectparts = sect[CONFIG_PREFIX_LEN:].split("_")
            try:
                layer_left = sectparts[0]
                layer_right = sectparts[1]
                if CONFIG_CHKTYP in cmobj[sect]:
                    conf_af_sections.append((sect,layer_left,layer_right))
                else:
                    checklog.warn("Audit Framework section '%s' does not have a check key '%s', skipping." % (section,CONFIG_CHECKTYP))
            except IndexError:
                checklog.warn("Problem parsing CM header '%s' for layer IDs, skipping header." % (sect))
        if left:
            pre_filter = len(conf_af_sections)
            conf_af_sections = filter(lambda sect: sect[1].lower()==left.lower(),conf_af_sections)
            checklog.debug("Left layer filter removed %d sections." % (pre_filter - len(conf_af_sections)))
        
        if right:
            pre_filter = len(conf_af_sections)
            conf_af_sections = filter(lambda sect: sect[2].lower()==right.lower(),conf_af_sections)
            checklog.debug("Right layer filter removed %d sections." % (pre_filter - len(conf_af_sections)))
        
        if not conf_af_sections:
            error_msg = "No valid sections (prefixed by '%s',containing '%s') were successfully parsed from file(s) '%s'." % (CONFIG_PREFIX,",".join(cmobj.files))
            checklog.error(error_msg)
            raise CheckerConfigError(error_msg)
        return conf_af_sections
    
    def get_checks(self):
        """ Returns the check types requested in the associated config.
            The method looks for the CONFIG_CHKTYP key (at time of writing, 'af_chk')
        """
        chk_types = self.cm.get((self.cm_section,CONFIG_CHKTYP),None)
        if not chk_types:
            error_msg = "No key '%s' found for Check section '%s', no CheckParts will be generated." % (CONFIG_CHKTYP,self.cm_section)
            checklog.error(error_msg)
            raise CheckerConfigError(error_msg)
        else:
            chk_types = parse_list(chk_types)
            checklog.debug("Found %d check types (%s) for Check section '%s'." % (len(chk_types),", ".join(chk_types),self.cm_section))
        return chk_types
    
    def get_parts(self,**kwargs):
        """ Does all the preparation work to generate the left and right CheckParts.
            Returns a tuple of (left parts, right parts)
        """
        
        # 0. has platform as fixed value 'hive'
        chk_platform = "hive" # fixed value
        # 1. gets the chk types from the [af_chk] key -> ['amt','cnt']
        chk_types = self.get_checks()
        # 2. for each of the chk types, get the config sub-dict for it:
        chk_dicts = {}
        for chk_typ in chk_types:
            # 2a. filter for items where the key passes .startswith("af_<chktyp>")
            # 2b. replace item[0] with key.replace("af_<chktyp>","") so we get the straight keys
            chk_keystr = "af_%s_" % (chk_typ)
            raw_chk_items = [(k.replace(chk_keystr,""),v) for k,v in self.cm[self.cm_section].items() if k.startswith(chk_keystr)]
            chk_items = []
            # formats the config dict to be useful parameters
            for k,v in raw_chk_items:
                #proc_v = v.strip().strip(""""'""")
                #chk_items.append((k,proc_v))
                chk_items.append((k,v))
            if chk_items:
                checklog.debug("For check type '%s', found sub-keys: %s" % (chk_typ,", ".join(k for k,v in chk_items)))
                chk_dicts[chk_typ] = dict(chk_items)
            else:
                checklog.debug("For check type '%s', found no sub-keys." % (chk_typ))
                chk_dicts[chk_typ] = {}
        
        # 3. for each of the individual config dicts, see if there are any prefixed by a digit and an underscore
        #    (raise these as a NotImplementedException since we haven't rolled out multiple-checks first stage)
        for chk_typ,chk_dict in chk_dicts.iteritems():
            for k in chk_dict.iterkeys():
                if MULTICONF_PREFIX.findall(k):
                    checklog.error("Found sub-configuration indicator in check type '%s', for key '%s'." % (chk_typ,k))
                    raise NotImplementedError("Multiple sub-configurations are not supported at this time, please change your configuration to use multiple transition checks instead.")
        
        
        dicts_left,dicts_right = [],[]
        
        # 4. iterate through each of the chktyp's config dicts
        for chk_typ,chk_dict in chk_dicts.iteritems():
            
            #   4b. if the config dict has _src_ and _tgt_ present in any keys, take key out of stack and assign _src_ side to left, _tgt_ side to right
            keys_left = [k for k,v in chk_dict.iteritems() if CONFIG_LEFT in k]
            items_left = [(k.replace(CONFIG_LEFT,""),chk_dict[k]) for k in keys_left]
            
            keys_right = [k for k,v in chk_dict.iteritems() if CONFIG_RIGHT in k]
            items_right = [(k.replace(CONFIG_RIGHT,""),chk_dict[k]) for k in keys_right]
            
            items_gen = [(k,v) for k,v in chk_dict.iteritems() if ((k not in keys_left) and (k not in keys_right))]
            
            #   4c. add all other keys to both dicts if not already present (throw if they're already in there)
            items_left = items_left + items_gen
            items_right = items_right + items_gen
            
            chk_left,chk_right = dict(items_left),dict(items_right)
            # 5. make two lists, left and right, containing tuples (platform,chktyp,configdict)
            dicts_left.append((chk_platform,chk_typ,chk_left))
            dicts_right.append((chk_platform,chk_typ,chk_right))
        
        parts_left, parts_right = [],[]
        # 6. with each 3-tuple from left and right, create CheckParts
        for plat,typ,confdict in dicts_left:
            checklog.debug("Setting up LEFT CheckPart for ('%s','%s') with extra args: %s." % (plat,typ,", ".join("%s:'%s'" % (k,v) for k,v in confdict.iteritems())))
            part = CheckPartRegistry.get_part(plat,typ)(layer=self.left_layer,filename=self.filename,cmobj=self.cm,**confdict)
            parts_left.append(part)
        for plat,typ,confdict in dicts_right:
            checklog.debug("Setting up RIGHT CheckPart for ('%s','%s') with extra args: %s." % (plat,typ,", ".join("%s:'%s'" % (k,v) for k,v in confdict.iteritems())))
            part = CheckPartRegistry.get_part(plat,typ)(layer=self.right_layer,filename=self.filename,cmobj=self.cm,**confdict)
            parts_right.append(part)
        # 7. return (LEFT LIST, RIGHT LIST) from the method
        return (parts_left,parts_right)