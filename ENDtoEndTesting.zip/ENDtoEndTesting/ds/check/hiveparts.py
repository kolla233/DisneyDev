from __future__ import unicode_literals

from collections import Iterable

from ds.logging import getChild,FsdLogger
checklog = getChild(FsdLogger,"check.hivepart")

from ds.core.configmgr import parse_list,parse_bool

from basepart import CheckPartRegistry,BaseCheckPart
from exceptions import CheckConfigError

from hiveutils import HiveFieldWrapper,HiveValidationQuery

LAYER_PREFIX = "flow"
DB_KEY = "FLOW_DB"
TBL_KEY = "FLOW_TBL"

class HiveCheckPart(BaseCheckPart):
    """ Type of CheckPart for use with Hive resources. Can be implemented directly,
        but most practical use is existing subclasses or new 
        registered (CheckPartRegistry) child classes."""
    
    __platform__ = "hive"
    
    FILE_VAR = "FsdAutoFileName"
    QUERY_BASE = "SELECT {select_q} FROM {target_db}.{target_tbl}"
    
    def __init__(self,*args,**kwargs):
        """ Accepts the following arguments:
            - db, the target database
            - tbl, the target table
            OR
            - layer, the target layer (which will be used to derive db, tbl from CM)
            
            - [opt] filename, a file to filter on with INPUT__FILE__NAME
            - [opt] cols, target columns to use in the HiveCheckPart
        """
        super(HiveCheckPart,self).__init__(self,*args,**kwargs)
        self._qresults = None
        self.target_db = kwargs.get("db",None)
        self.target_tbl = kwargs.get("tbl",None)
        self.target_layer = kwargs.get("layer",None)
        # filter filename if INPUT__FILE__NAME is called for
        self.filename = kwargs.get("filename",None)
        if not (self.target_db and self.target_tbl):
            self.get_layer_info(self.target_layer,kwargs.get("cmobj"))
        self.target_cols = parse_list(kwargs.get("cols",None))
        if self.target_cols:
            # perform a quick security check first
            ban_chars = [';',',','(',')']
            if any(any((ban_char in col) for col in self.target_cols)for ban_char in ban_chars):
                raise CheckConfigError("Invalid characters present in a HivePart column definition ('%s')" % (self.target_cols))
        
        self.conds = parse_list(kwargs.get("conds",None))
        
        self.chkfile = parse_bool(kwargs.get('chkfile','true'))
        if self.chkfile:
            filestr = self.filename if self.filename else self.FILE_VAR
            self.conds.append("INPUT__FILE__NAME LIKE '%{filename}%'".format(filename=filestr))
            
        field_wrappers = parse_list(kwargs.get("wrappers",None))
       
        if parse_bool(kwargs.get('cast',False)):
            field_wrappers.insert(0,'cast')
        self.field_wrappers = self.resolve_wrappers(field_wrappers)

    
    def get_layer_info(self,layer,cmobj):
        cm_section = "%s_%s" % (LAYER_PREFIX,layer.lower())
        checklog.debug("Resolving target database and table via ConfigManager section '%s' for layer '%s'" %(cm_section,layer))
        self.target_db = cmobj[cm_section,DB_KEY]
        self.target_tbl = cmobj[cm_section,TBL_KEY]
    
    def resolve_wrappers(self,field_wrapper_names):
        wrapper_objs = []
        for wrapper_name in field_wrapper_names:
            try:
                wrapper_objs.append(HiveFieldWrapper.wrappers[wrapper_name])
            except KeyError:
                raise CheckConfigError("Error wrapping Hive columns - wrapper '%s' not found." % (wrapper_name))
        return wrapper_objs
    
    def get_cols(self,alias=True):
        """ Returns a processed columns list for use by build_select, etc.
            Will also wrap the column as needed using self.field_wrappers. """
        cols_list = [] # holds processed column list
        for col in self.target_cols:
            proc_col = col # holds processed column between stages
            if self.field_wrappers:
                for wrapper in self.field_wrappers:
                    proc_col = wrapper.wrap(proc_col)
                if alias:
                    if col == "*": # workaround since you can't have an alias of "*", oops.
                        col = "cnt"
                    elif "," in col or " " in col:
                        col = col.replace(" ","").replace(",","").lower()
                    proc_col = "%s AS %s" % (proc_col,col)
            cols_list.append(proc_col)
        return cols_list
    
    def build_select(self):
        """ Responsible for building the 'meat' of the 
            SELECT portion of the query. Uses get_cols(). """
        cols_list = self.get_cols()
        selstr = ",".join(cols_list)
        return selstr
        
    def build_where(self):
        """ Builds the conditional part of the query. By 
            default joins each member of self.conds with AND."""
        wherestr = " "
        if self.conds:
            wherestr += "WHERE " + " AND ".join(self.conds)
        return wherestr
    
    def build_query(self):
        qstr = self.QUERY_BASE.format(select_q=self.build_select(),target_db=self.target_db,target_tbl=self.target_tbl)
        qstr += self.build_where()
        return qstr
    
    def execute(self,*args,**kwargs):
        """ Runs the query and returns the Decimal-formatted results."""
        hq = HiveValidationQuery(self.build_query(),**kwargs)
        hq.execute()
        self.results = hq.results
        
@CheckPartRegistry.register
class HiveAmountPart(HiveCheckPart):
    """ Implements an amount/sum check in Hive.
        The 'amt' check also accepts an 'indcols' argument, which controls
        whether the sum()'d fields are added together or kept as separate columns
        within the final comparison. """
    __checks__ = ("amt","amount")
    
    def __init__(self,*args,**kwargs):
        n_kwargs = kwargs
        n_kwargs['wrappers'] = parse_list(n_kwargs.get("wrappers",None)) + ['sum']
        super(HiveAmountPart,self).__init__(self,*args,**kwargs)
        self.indcols = parse_bool(kwargs.get('indcols',False))
    
    def build_select(self):
        """ Overrides the default build_select to [optionally] join with '+' instead of ', '."""
        if self.indcols: # the independent columns flag
            return super(HiveAmountPart,self).build_select()
        else:
            cols_list = self.get_cols(alias=False)
            selstr =  "+".join(cols_list) + " as amt"
            return selstr

@CheckPartRegistry.register
class HiveCountPart(HiveCheckPart):
    """ Implements a count check in Hive."""
    __checks__ = ("cnt","count")
    
    def __init__(self,*args,**kwargs):
        n_kwargs = kwargs
        n_kwargs['wrappers'] = parse_list(n_kwargs.get("wrappers",None)) + ['cnt']
        n_kwargs['cols'] = ["*"]
        super(HiveCountPart,self).__init__(self,*args,**n_kwargs)

@CheckPartRegistry.register
class HiveDistinctCountPart(HiveCheckPart):
    """ Implements a distinct count check in Hive."""
    
    __checks__ = ("cntd","distinct count")
    
    def __init__(self,*args,**kwargs):
        n_kwargs = kwargs
        n_kwargs['wrappers'] = parse_list(n_kwargs.get("wrappers",None)) + ['cnt']
        real_cols = parse_list(kwargs.get("cols"))
        n_kwargs['cols'] = []
        super(HiveDistinctCountPart,self).__init__(self,*args,**n_kwargs)
        self.target_cols = ["DISTINCT " + ",".join(real_cols)]