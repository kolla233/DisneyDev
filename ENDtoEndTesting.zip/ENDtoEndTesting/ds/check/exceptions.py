""" All custom exceptions for fsd.check."""

class FsdCheckException(Exception):
    """ Base FsdCheck library exception."""
    pass

class CheckOutOfBalance(FsdCheckException):
    """ for when CheckParts fail to equal each other in a Checker."""
    pass

class CheckPartException(FsdCheckException):
    pass

class CheckConfigError(CheckPartException):
    """ for when arguments to a CheckPart cause failure."""
    pass

class CheckExecutionError(CheckPartException):
    """ for when the execution of a CheckPart fails. """
    pass

class CheckTimeoutError(CheckPartException):
    """ raised when a CheckPart takes longer than the defined timeout window to run."""
    pass

class CheckerError(FsdCheckException):
    """ General Checker exception."""
    pass

class CheckerExecutionError(CheckerError):
    """ for when Checker execution fails for reasons other than a CheckExecutionError. """
    pass

class CheckerConfigError(CheckerError):
    """ Used to signal a configuration failure with the Checker instance."""
    pass

class InvalidCheckError(CheckerConfigError):
    """ for when the check type provided is invalid."""
    pass

class UnsupportedCheckPlatform(CheckerConfigError):
    """ for when the check/platform combination is not available."""
    pass

class UnsupportedFrameworkError(CheckerConfigError):
    """ when the framework specified is not available."""
    pass