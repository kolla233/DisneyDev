# -*- coding: utf-8 -*-
"""
Created on Tue May 21 18:33:37 2019

@author: bonaresh
"""

# importing python module "unittest"

import unittest
import filecmp
import subprocess
import os
from Helper import Runcommand
from ds.core.configmgr import ConfigManager
from common.ETL_FRAMEWORK_HELPER import Etl_FrameWorkHelper

etllog = getChild(FsdLogger,"ETLOperations")

class FileToFileDMT(unittest.TestCase):
    
     def __init__(self):
            self.runcommand = Runcommand()
            self.paramFile = "EXECUTION_TEST"
            self.hdfs_work_directory = "/user/srcpath/"
            self.local_work_directory = "/root/tgtpath/"
            self.fileID = "fileid3"
            self.logDir = "/root/hcsc/etl_logs"
    
     def  test_HDFStoHDFS(self):
          """perform HDFS to HDFS file movement operations when direct move = true """
          cm = ConfigManager("CM_FSD_FILEMOVER",flow="EXECUTION_TEST")
          py_cmd = 'python /root/data-solutions/fsd/consumption/src/scripts/common/ETLOperations.py -param "path=\'{0}\'" -param "work_directory_hdfs=\'{1}\'" -param "work_directory_local=\'{2}\'" -param "Fileid={3}" -param "log_directory=\'{4}\'"  -param "mode=\'{5}\'" '.format(self.paramFile, self.hdfs_work_directory,self.local_work_directory,self.fileID,self.logDir,self.mode)
          s_return, s_output, s_err = self.runcommand.run_cmd(py_cmd, shell_cmd=True)
          if s_return == 0:
              print("Script has been executed successfully")
              tgt_path = cm["flow_fileid3","tgt_path"]
              Expected_path = cm["flow_fileid3","Expected_path"]
              temp_path = cm["flow_fileid3","temp_path"]
              """Perform data validation"""
              etllog.debug("Started moving file from source %s to target %s" %(tgt_path, temp_path))
              Etl_FrameWorkHelper.HDFSToLocalCopy(tgt_path, temp_path)                
              etllog.debug("Moved from HDFS source %s to local target path %s is sucessful" %(tgt_path, temp_path))
              Testresult = self.assertTrue(filecmp.cmp(temp_path,Expected_path))
              if Testresult == None:
                print ("Expected File comparison has been done successfully")
              else:
                print ("Expected File comparison has been failed")   