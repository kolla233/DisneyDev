# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 15:28:25 2019

@author: bonresh
"""

import subprocess

class Runcommand:
    
    def run_cmd(self,args_list, shell_cmd=False):
        print(args_list)
        proc = subprocess.Popen(args_list, shell=shell_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return = proc.returncode
        return s_return, s_output, s_err