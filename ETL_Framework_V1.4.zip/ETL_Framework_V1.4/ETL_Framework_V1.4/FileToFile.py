# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 16:46:36 2019

@author: krajkumar
"""

from PigCaller import PigCaller
from DataMover import DataMover
from ds.logging.main import ETLLogger,getChild,setDebug,setInfo,setWarn,setError
import sys, traceback 
filelogger = getChild(ETLLogger,"FileToFileLogging")

class FileToFile :

    def ExecuteMovement(self,configData, hdfs_work_directory, local_work_directory):
        pigCaller = PigCaller()
        dataMover = DataMover()
    
        if configData.src_in_local and configData.tgt_in_local :
            try:  
              filelogger.debug("process intiated to move %s from local location to target local location(%s)" %(configData.src_path,configData.tgt_path))
              temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
              temp_directory_in_hdfs = hdfs_work_directory + "/in_" + configData.fileid
              dataMover.createHDFSDir(temp_directory_in_hdfs)
              dataMover.localToHDFS(configData.src_path, temp_directory_in_hdfs)
              pigCaller.executePig1(configData.move_type, temp_directory_in_hdfs, configData.src_reader, configData.source_header , configData.all_schema
              ,configData.add_schema, configData.select_schema,configData.tgt_writer, temp_directory_hdfs, configData.write_header)
              
              dataMover.RemoveHDFSDir(temp_directory_in_hdfs)
              dataMover.MergeFilesToOneFile(temp_directory_hdfs, configData.tgt_path)
              dataMover.RemoveHDFSDir(temp_directory_hdfs)
              filelogger.debug("Source(local) file %s successfully moved to target local location(%s)" %(configData.src_path,configData.tgt_path))
            except Exception as e:            
              filelogger.debug("Exception Occured. Cleaning All temporary files creatred. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ")
              dataMover.RemoveHDFSDir(temp_directory_in_hdfs, raiseException = False)
              dataMover.RemoveLFSFile(configData.tgt_path, raiseException = False)
              dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
              
              exc_info = sys.exc_info()
              raise (exc_info[1],None,exc_info[2])
              sys.exit(1)
              
         
        elif  configData.src_in_local and not configData.tgt_in_local :
            try:
              filelogger.debug("process intiated to move %s from local location to target HDFS location(%s)" %(configData.src_path,configData.tgt_path))            
              temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
              temp_local_file_path = local_work_directory + "/" + configData.fileid
              temp_directory_in_hdfs = hdfs_work_directory + "/in_" + configData.fileid
              dataMover.createHDFSDir(temp_directory_in_hdfs)
              dataMover.localToHDFS(configData.src_path, temp_directory_in_hdfs)
              pigCaller.executePig1(configData.move_type,temp_directory_in_hdfs, configData.src_reader,  configData.source_header, configData.all_schema,
                                       configData.add_schema, configData.select_schema,
                                       configData.tgt_writer, temp_directory_hdfs, configData.write_header)
              
              dataMover.RemoveHDFSDir(temp_directory_in_hdfs)
              dataMover.MergeFilesToOneFile(temp_directory_hdfs, temp_local_file_path)
              dataMover.RemoveHDFSDir(temp_directory_hdfs)
              dataMover.localToHDFS(temp_local_file_path, configData.tgt_path)
              dataMover.RemoveLFSFile(temp_local_file_path)
            
              filelogger.debug("Source(local) file %s successfully moved to target HDFS location(%s)" %(configData.src_path,configData.tgt_path))
            except Exception as e:
              filelogger.debug("Exception Occured. Cleaning All temporary files creatred. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ")
              dataMover.RemoveHDFSDir(temp_directory_in_hdfs, raiseException = False)
              dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
              dataMover.RemoveLFSFile(temp_local_file_path, raiseException = False)
              dataMover.RemoveHDFSFile(configData.tgt_path, raiseException = False)
              
              exc_info = sys.exc_info()
              raise (exc_info[1],None,exc_info[2])
              sys.exit(1)            
             
            
        elif not configData.src_in_local and  configData.tgt_in_local :
            try:
              filelogger.debug("process intiated to move %s from HDFS location to target local location(%s)" %(configData.src_path,configData.tgt_path))        
              temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
              pigCaller.executePig1(configData.move_type,configData.src_path, configData.src_reader,  configData.source_header, configData.all_schema,
                                       configData.add_schema, configData.select_schema,
                                       configData.tgt_writer, temp_directory_hdfs, configData.write_header)
              
              dataMover.MergeFilesToOneFile(temp_directory_hdfs, configData.tgt_path)
              dataMover.RemoveHDFSDir(temp_directory_hdfs)
              filelogger.debug("Source(HDFS) file %s successfully moved to target local location(%s)" %(configData.src_path,configData.tgt_path))
            except Exception as e:
              filelogger.debug("Exception Occured. Cleaning All temporary files creatred. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ")
              
              dataMover.RemoveLFSFile(temp_local_file_path, raiseException = False)
              dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
              
              exc_info = sys.exc_info()
              raise (exc_info[1],None,exc_info[2])
              sys.exit(1)             
               
        elif not configData.src_in_local and not configData.tgt_in_local :
            try:
              filelogger.debug("process intiated to move %s from HDFS location to target HDFS location(%s)" %(configData.src_path,configData.tgt_path))
              temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
              temp_local_file_path = local_work_directory + "/" + configData.fileid
              pigCaller.executePig1(configData.move_type,configData.src_path, configData.src_reader,  configData.source_header, configData.all_schema,
                                       configData.add_schema, configData.select_schema,
                                       configData.tgt_writer, temp_directory_hdfs, configData.write_header)
              dataMover.MergeFilesToOneFile(temp_directory_hdfs, temp_local_file_path)
              dataMover.RemoveHDFSDir(temp_directory_hdfs)
              dataMover.localToHDFS(temp_local_file_path, configData.tgt_path)
              dataMover.RemoveLFSFile(temp_local_file_path)
              filelogger.debug("Source(HDFS) file %s successfully moved to target HDFS location(%s)" %(configData.src_path,configData.tgt_path))
            except Exception as e:
              filelogger.debug("Exception Occured. Cleaning All temporary files creatred. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ")
              dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
              dataMover.RemoveLFSFile(temp_local_file_path, raiseException = False)
              dataMover.RemoveHDFSFile(configData.tgt_path, raiseException = False)
              
              exc_info = sys.exc_info()
              raise (exc_info[1],None,exc_info[2])
              sys.exit(1)             
        