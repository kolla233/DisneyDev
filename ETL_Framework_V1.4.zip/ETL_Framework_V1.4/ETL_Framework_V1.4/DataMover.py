# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 15:29:07 2019

@author: krajkumar
"""

from Helper import Runcommand
from ds.logging.main import ETLLogger, getChild
from CustomExceptions import ShellCommandException

datalog = getChild(ETLLogger, "datalogger")

class DataMover:
    
    def __init__(self):
        self.runcommand = Runcommand()
    
    def ExecuteCommand(self, cmd, isShellCmd=False, raiseException=True):
    
        if not isShellCmd :
            (ret, out, err) = self.runcommand.run_cmd(cmd)
        else :
            (ret, out, err) = self.runcommand.run_cmd(cmd, shell_cmd=True)
            
        if ret != 0 and raiseException :
            datalog.error("execution of command ('%s') failed. Error is ('%s')" %(cmd, err))
            raise ShellCommandException("Bad Command Found '%s'" %(err))
        else:
            datalog.debug("Execution of command ('%s') is Sucess. Output is ('%s')" %(cmd, out))
            return ret, out , err

    def localToHDFS(self, src_path, tgt_path):
        datalog.debug("local to hdfs file movement started")
        cmd = ['hdfs', 'dfs', '-copyFromLocal', src_path, tgt_path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)

    def HDFSToLocal(self, src_path, tgt_path):
        datalog.debug("Hdfs to Local file movement")
        cmd = ['hdfs', 'dfs', '-copyToLocal', src_path, tgt_path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)

    def HDFSToHDFS(self, src_path, tgt_path):
        datalog.debug("Hdfs to Hdfs movement")
        cmd = ['hdfs', 'dfs', '-cp', src_path, tgt_path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)

    def localToLocal(self, src_path, tgt_path):
        datalog.debug("local to local file movement started")
        cmd = ['cp', src_path, tgt_path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)
    
    def RemoveHDFSDir(self, path, raiseException=True):
        datalog.debug("Started Remove hdfs direcotry")
        cmd = ['hdfs', 'dfs', '-rm', '-r', path]
        (ret, out, err) = self.ExecuteCommand(cmd, raiseException = raiseException)
        return (ret, out, err)


    def RemoveHDFSFile(self, path, raiseException=True):
        datalog.debug("Removing hdfs file")
        cmd = ['hdfs', 'dfs', '-rm', path]
        (ret, out, err) = self.ExecuteCommand(cmd, raiseException = raiseException)
        return (ret, out, err)

    def RemoveLFSFile(self, path, raiseException=True):
        datalog.debug("removing LFSFile")
        cmd = ['rm', path]
        (ret, out, err) = self.ExecuteCommand(cmd, raiseException = raiseException)
        return (ret, out, err)
    
    def RemoveLocalDir(self, path, raiseException=True):
        datalog.debug("Removing the local directory structure")
        cmd = ['rm', '-r', path]
        (ret, out, err) = self.ExecuteCommand(cmd, raiseException = raiseException)
        return (ret, out, err)

    def createHDFSDir(self, path):
        datalog.debug("creating HDFS File Directory")
        cmd = ['hdfs', 'dfs', '-mkdir', '-p', path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)

    def createLFSDir(self, path):
        datalog.debug("Creating LFS Directory")
        cmd = ['mkdir', '-p', path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        return (ret, out, err)


    
    def MergeFilesToOneFile(self,src_folder_path, target_file_path):
        datalog.debug("Merging Files of HDFS to Local file")
        cmd = ['hdfs', 'dfs', '-getmerge', src_folder_path, target_file_path]
        (ret, out, err) = self.ExecuteCommand(cmd)
        #(ret, out, err)= self.runcommand.run_cmd(['hdfs', 'dfs', '-getmerge', src_folder_path, target_file_path]) 
        return (ret, out, err)
    
    
    def MergeFilesToOneFileLOcal(self,src_folder_path, target_file_path):
        cmd = "cat {0}/* > {1}".format(src_folder_path, target_file_path)
        (ret, out, err) = self.ExecuteCommand(cmd, isShellCmd = True)
        #(ret, out, err)= self.runcommand.run_cmd(cmd, shell_cmd=True) 
        return (ret, out, err)
    
    
    def checkFileExists(self, path, local=True) :
        if local:
            cmd = "[ -e {0} ]; echo $?".format(path)
        else :
            cmd = "hdfs dfs -test -f {0}; echo $?".format(path)
        
        (ret, out, err) = self.ExecuteCommand(cmd, isShellCmd = True)
        #(ret, out, err)= self.runcommand.run_cmd(cmd, shell_cmd=True)        
        return (ret, out, err)
    
    def checkDirectoryExists(self, path, local=True):
        if local :
            cmd = "[ -d {0} ]; echo $?".format(path)
        else :
            cmd = " hdfs dfs -test -d {0}; echo $?".format(path)
        
        (ret, out, err) = self.ExecuteCommand(cmd, isShellCmd = True)
        #(ret, out, err)= self.runcommand.run_cmd(cmd, shell_cmd=True)  
        return (ret, out, err)
    
        
    
if __name__ == "__main__" :
    print ("called 1")
    x = DataMover()
    print(x.checkDirectoryExists("/user/ramcloudxlablearn16259", local=False))
