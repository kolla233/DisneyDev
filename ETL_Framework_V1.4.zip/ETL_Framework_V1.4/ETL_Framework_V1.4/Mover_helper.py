# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 17:59:23 2019

@author: krajkumar
"""

class Mover_helper:
    
    def updateSelect_schema(self, configData):
        if configData.select_schema == "":
            configData.select_schema = "*"
            
    def updateNewColumns_schema(self, configData):
        if configData.add_schema == "":
           configData.add_schema = "*"
        else:
            configData.add_schema = "* , {0}".format(configData.add_schema)
            
    def update_configData(self, configData):
        self.updateSelect_schema(configData)
        self.updateNewColumns_schema(configData)
