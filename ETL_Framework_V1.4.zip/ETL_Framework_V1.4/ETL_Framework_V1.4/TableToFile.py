# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 17:01:09 2019

@author: krajkumar
"""

from PigCaller import PigCaller
from DataMover import DataMover
from ds.logging.main import ETLLogger, getChild
import sys, traceback

tablog = getChild(ETLLogger, "tablog")

class TableToFile:

    def ExecuteMovement(self, configData, hdfs_work_directory, local_work_directory):
        tablog.debug("Execute Movement")
        pigCaller = PigCaller()
        dataMover = DataMover()
        try:
            if configData.tgt_in_local:
                try:
                    temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
                    tablog.info("Pig Script is executing ")
                    pigCaller.executePg1(configData.move_type, configData.src_path, configData.src_reader,
                                          configData.source_header, configData.all_schema,
                                          configData.add_schema, configData.select_schema,
                                          configData.tgt_writer, temp_directory_hdfs, configData.write_header)
                    tablog.info("Pig Script is completed ")
                    dataMover.MergeFilesToOneFile(temp_directory_hdfs, configData.tgt_path)
                    tablog.info("Merging the all hdfs files from (%s) location to the local direcory (%s)" %(configData.src_path,configData.tgt_path))
                    dataMover.RemoveHDFSDir(temp_directory_hdfs)
                    tablog.info("Hdfs temp directory remved (%s)" %(temp_directory_hdfs))
                    
                except Exception as e:
                    
                    dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
                    dataMover.RemoveLFSFile(configData.tgt_path, raiseException = False)
                    
                    exc_info = sys.exc_info()
                    raise (exc_info[1],None,exc_info[2])
                    sys.exit(1)


            elif not configData.tgt_in_local:
                try:
                    temp_directory_hdfs = hdfs_work_directory + "/" + configData.fileid
                    temp_local_file_path = local_work_directory + "/" + configData.fileid
                    pigCaller.executePig1(configData.move_type, configData.src_path, configData.src_reader,
                                          configData.source_header, configData.all_schema,
                                          configData.add_schema, configData.select_schema,
                                          configData.tgt_writer, temp_directory_hdfs, configData.write_header)

                    dataMover.MergeFilesToOneFile(temp_directory_hdfs, temp_local_file_path)
                    dataMover.RemoveHDFSDir(temp_directory_hdfs)
                    dataMover.localToHDFS(temp_local_file_path, configData.tgt_path)
                    dataMover.RemoveLFSFile(temp_local_file_path)
                except Exception as e:
                    
                    dataMover.RemoveHDFSDir(temp_directory_hdfs, raiseException = False)
                    dataMover.RemoveLFSFile(temp_local_file_path, raiseException = False)
                    dataMover.RemoveHDFSFile(configData.tgt_path, raiseException = False)
                    
                    exc_info = sys.exc_info()
                    raise exc_info[1],None,exc_info[2]
                    sys.exit(1)
                    
        except Exception as e:
            error_msg = "Script failed with error '%s'." % (unicode(e))
            tablog.error(traceback.print_exc())
            tablog.error(error_msg)
            exc_info = sys.exc_info()
            raise exc_info[1],None,exc_info[2]
            sys.exit(1)
