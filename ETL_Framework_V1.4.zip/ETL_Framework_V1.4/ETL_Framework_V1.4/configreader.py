from ConfigData import ConfigData
import ConfigParser

class ConfigReader:

    def getconfigdata(self, path, fileid):
        config = ConfigParser.ConfigParser({'source_header':'False', 'write_header':'False', 'direct_move':'True',
                                            'src_delimiter':',','all_schema':'','add_schema':'', 'select_schema':'',
                                            'tgt_delimiter':',',
                                            'src_column_width':'', 'tgt_column_width':''})
        config.read(path)
        move_type = config.get(fileid,"move_type")
        if move_type == "dfiletodfile":
            return self.getdfiletodfile(config,fileid)
        elif move_type == "dfiletofwfile":
            return self.getdfiletofwfile(config,fileid)
        elif move_type == "fwfiletodfile":
            return self.getfwfiletodfile(config,fileid)
        elif move_type == "fwfiletofwfile":
            return self.getfwfiletofwfile(config,fileid)
        elif move_type == "tabletodfile":
            return self.gettabletodfile(config,fileid)
        elif move_type == "tabletofwfile":
            return self.gettabletofwfile(config,fileid)

        # Reading the configuration values based on the filetofile configuration file
        
    
    def getdfiletodfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"src_path")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = config.get(fileid,"src_in_local").strip() == 'True'
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = config.get(fileid,"source_header").strip() == 'True'
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = config.get(fileid,"src_delimiter")
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_delimiter")
        readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local, source_header,target_header,src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
    def getdfiletofwfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"src_path")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = config.get(fileid,"src_in_local").strip() == 'True'
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = config.get(fileid,"source_header").strip() == 'True'
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = config.get(fileid,"src_delimiter")
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_column_width")
        readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local,source_header, target_header ,src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
    def getfwfiletodfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"src_path")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = config.get(fileid,"src_in_local").strip() == 'True'
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = config.get(fileid,"source_header").strip() == 'True'
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = config.get(fileid,"src_column_width")
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_delimiter")
        readData = ConfigData(fileid, move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local, source_header, target_header, src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
    def getfwfiletofwfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"src_path")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = config.get(fileid,"src_in_local").strip() == 'True'
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = config.get(fileid,"source_header").strip() == 'True'
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = config.get(fileid,"src_column_width")
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_column_width")
        readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local,source_header, target_header, src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
    def gettabletodfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"dbtable")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = False
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = False
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = None
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_delimiter")
        readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local, source_header , target_header, src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
    def gettabletofwfile(self, config, fileid):
        fileid = config.get(fileid,"fileid")
        move_type = config.get(fileid,"move_type")
        src_path = config.get(fileid,"dbtable")
        tgt_path = config.get(fileid,"tgt_path")
        direct_move = config.get(fileid,"direct_move").strip() == 'True'
        src_in_local = False
        tgt_in_local =  config.get(fileid,"tgt_in_local").strip() == 'True'
        source_header = False
        target_header = config.get(fileid,"write_header").strip() == 'True'
        src_read_value = None
        all_schema = config.get(fileid,"all_schema")
        add_schema = config.get(fileid,"add_schema")
        select_schema = config.get(fileid,"select_schema")
        tgt_write_value = config.get(fileid,"tgt_column_width")
        readData = ConfigData(fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local,source_header, target_header, src_read_value,all_schema,add_schema,select_schema,tgt_write_value)
        return readData
    
        
        
if __name__ == '__main__':
    reader = ConfigReader()
    

