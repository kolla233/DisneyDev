# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 15:35:20 2019

@author: krajkumar
"""

from DataMover import DataMover
from configreader import ConfigReader
from PigCaller import PigCaller
import sys,traceback
from pprint import pprint
from FileToFile import FileToFile
from TableToFile import TableToFile
from Mover_helper import Mover_helper
from ConfigValidator import ConfigValidator
from ds.logging  import getChild,ETLLogger,setDebug,setInfo,setError

etllog = getChild(ETLLogger,"ETLOperations") 

class ETLOperations:
    
    def execute(self,hdfs_work_directory, local_work_directory, conf_path, fileid):
        try:
            reader = ConfigReader()
	    
            configData = reader.getconfigdata(conf_path,fileid)
            etllog.info("The config data is %s"%(vars(configData)))
            configValidator =  ConfigValidator()
            valid1 = configValidator.validIOPaths(configData)
            if not valid1 :
                etllog.error("Please Provide Valid Paths.")
                sys.exit(1) 
            valid2 =  configValidator.validateConfig(configData)
            if not valid2:
                etllog.error("Please Provide validf config Data. ")
                sys.exit(1) 

            dataMover = DataMover()
            if(configData.direct_move):      
                    if configData.src_in_local and configData.tgt_in_local :
                        etllog.info("Started moving file from source %s to target %s" %(configData.src_path,configData.tgt_path))
                        dataMover.localToLocal(configData.src_path, configData.tgt_path)
                        etllog.info("Moved file from local source %s to local target %s is sucessful" %(configData.src_path,configData.tgt_path))
                    elif not configData.src_in_local and configData.tgt_in_local :
                        etllog.debug("Started moving file from source %s to target %s" %(configData.src_path,configData.tgt_path))
                        dataMover.HDFSToLocal(configData.src_path, configData.tgt_path)
                        etllog.debug("Moved from HDFS sorce %s to local target path %s is sucessful" %(configData.src_path,configData.tgt_path))    
                    elif configData.src_in_local and not configData.tgt_in_local :
                        etllog.debug("Started moving file from source %s to target %s" %(configData.src_path,configData.tgt_path))
                        dataMover.localToHDFS(configData.src_path, configData.tgt_path)
                        etllog.debug("Moved file from local source path %s to HDFS target path is sucessful" %(configData.src_path,configData.tgt_path))
                    elif not configData.src_in_local and not configData.tgt_in_local :
                        etllog.debug("Started moving file from source %s to target %s" %(configData.src_path,configData.tgt_path))
                        dataMover.HDFSToHDFS(configData.src_path, configData.tgt_path)
                        etllog.debug("Moved file from HDFS source path %s to HDFS target path %s is sucessful" %(configData.src_path,configData.tgt_path))
                    else:
                        pass  
            else :
                mover_helper = Mover_helper()
                mover_helper.update_configData(configData)
                
                if configData.move_type == "tabletodfile" or configData.move_type == "tabletofwfile" :
                        tabletofile = TableToFile()
                        tabletofile.ExecuteMovement(configData, hdfs_work_directory, local_work_directory)
                elif configData.move_type == "dfiletotable" or configData.move_type == "fwfiletotable" :
                     pass
                else :
                        filetifile = FileToFile()
                        filetifile.ExecuteMovement(configData, hdfs_work_directory, local_work_directory)
        except Exception as e:
            error_msg = "Script failed with error '%s'." % (unicode(e))
            etllog.error(traceback.print_exc())
            etllog.error(error_msg)
            exc_info = sys.exc_info()   
            sys.exit(1) 
if __name__ == "__main__":
    all_arguments = sys.argv[:]
    etllog.info("List of arguments passed are %s "%(all_arguments))
    if len(all_arguments) > 6 :
        etllog.debug("Please provide only six arguments eg: param1: pythonfile(ETLOperations.py), param2: src_path(/root/abc.txt), param3: tgt_path(/user/root/abc/abc.txt) param5: configFileName(filetofile.cnf) param6: logFile path(/root/logpath/ ");
    elif len(all_arguments) < 6 :
        etllog.debug("Please provide  six arguments eg: param1: pythonfile(ETLOperations.py), param2: src_path(/root/abc.txt), param3: tgt_path(/user/root/abc/abc.txt) param5: configFileName(filetofile.cnf) param6: logFile path(/root/logpath/");
    else :    
        ob = ETLOperations()
        ob.execute(sys.argv[1],sys.argv[2], sys.argv[3], sys.argv[4])
        etllog.debug("Processed the file sucessful");
