"""
ETL base logger configuration and setup.

"""
import logging, time
import datetime
import sys

ETLLogger = logging.getLogger('ETL')
ETLLogger.setLevel(logging.DEBUG)
log_path=sys.argv[5]

# Formatter to use UTC (always UTC!)
class UTCFormatter(logging.Formatter):
    converter = time.gmtime
# Basic log formatting
ETLFormatter = UTCFormatter('%(asctime)s %(name)-25s %(levelname)-8s %(message)s',
                      datefmt='%Y-%m-%d %H:%M:%S')

# Console handler
console = logging.StreamHandler()
console.setFormatter(ETLFormatter)
console.setLevel(logging.DEBUG)
ETLLogger.addHandler(console)

datetimenow = datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S").replace(':', '.')
ch = logging.FileHandler(log_path+datetimenow+ '.log')
ch.setLevel(logging.DEBUG)
ch.setFormatter(ETLFormatter)
ETLLogger.addHandler(ch)

def getChild(logger,name):
    """ Reproduces the behavior of 'getChild' on a Logger instance in 2.7."""
    return logging.getLogger(logger.name+"."+name)

def setDebug():
    """ Sets the ETLLogger instance to log level DEBUG."""
    ETLLogger.setLevel(logging.DEBUG)

def setInfo():
    """ Sets the ETLLogger instance to log level INFO."""
    ETLLogger.setLevel(logging.INFO)

def setWarn():
    """ Sets the ETLLogger instance to log level WARN."""
    ETLLogger.setLevel(logging.WARN)

def setError():
    """ Sets the ETLLogger instance to log level WARN."""
    ETLLogger.setLevel(logging.ERROR)

