# -*- coding: utf-8 -*-
"""
Created on Thu Mar 28 14:50:57 2019

@author: krajkumar
"""

class ShellCommandException(Exception):
    pass
class PigScriptException(Exception):
    pass