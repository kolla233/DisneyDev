class ConfigData:

# Created parameterized constructer to read all the values
    def __init__(self,fileid,move_type,src_path,tgt_path,direct_move,src_in_local,tgt_in_local, source_header, target_header, src_read_value,all_schema,add_schema,select_schema,tgt_write_value):

        self.fileid = fileid
        self.move_type = move_type
        self.src_path = src_path
        self.tgt_path = tgt_path
        self.direct_move = direct_move
        self.src_in_local = src_in_local
        self.tgt_in_local = tgt_in_local
        self.source_header = source_header
        self.write_header = target_header
        self.src_reader = src_read_value
        self.all_schema = all_schema
        self.add_schema = add_schema
        self.select_schema = select_schema
        self.tgt_writer = tgt_write_value

#        if move_type == "dfiletodfile":
#            self.delimiter = src_read_value
#            self.tgt_delimiter = tgt_write_value
#        elif move_type == "dfiletofwfile":
#            self.delimiter = src_read_value
#            self.tgt_column_width = tgt_write_value
#        elif move_type == "fwfiletodfile":
#            self.src_column_width = src_read_value
#            self.tgt_delimiter = tgt_write_value
#        elif move_type == "fwfiletofwfile":
#            self.src_column_width = src_read_value
#            self.tgt_column_width = tgt_write_value



