# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 15:59:30 2019

@author: krajkumar
"""
from DataMover import DataMover
import os
from ds.logging  import getChild,ETLLogger,setDebug,setInfo,setError

log = getChild(ETLLogger,"ETLOperations") 

class ConfigValidator:
    
    def validateConfig(self, config):
        valid = True
        if (not config.direct_move) and (config.move_type == "dfiletodfile" or config.move_type == "dfiletofwfile" or config.move_type == "fwfiletodfile" or config.move_type == "fwfiletofwfile") :
            if config.src_reader == '' :
                log.error ("please provide valid Source src_delimiter/src_column_width in the Config file for the Movement id %s "  %(config.fileid))
                valid = False
            if config.tgt_writer == '':
                log.error ("please provide valid Source tgt_delimiter/tgt_column_width in the Config file for the Movement id %s " %(config.fileid))
                valid = False
            if config.all_schema == '':
                log.error ("please provide valid Source src_schema in the Config file for the Movement id %s " %(config.fileid))
                valid = False
                    
        return valid
    
    def validIOPaths(self, config) :
        
        dataMover = DataMover()
        
        valid = True
        
        if  config.move_type == 'dfiletodfile'  or  config.move_type == 'dfiletofwfile' or config.move_type == 'fwfiletodfile' or config.move_type == 'fwfiletofwfile' :
            (ret,out,err) = dataMover.checkFileExists(config.src_path, config.src_in_local)
            if out.strip() == '1':
                valid = False
                log.error ("Input Source file %s not exists " %(config.src_path))
            (ret,out,err) = dataMover.checkFileExists(config.tgt_path, config.tgt_in_local)
            if out.strip() == '0':
                valid = False
                log.error ("Target File %s already exists " %(config.tgt_path))
        
            opDir = os.path.dirname(os.path.abspath(config.tgt_path))
            (ret,out,err) = dataMover.checkDirectoryExists(opDir, config.tgt_in_local)
            if out.strip() == '1':
                valid = False
                log.error ("Target Directory %s not exists " %(opDir))

        elif config.move_type == 'tabletodfile' or config.move_type == 'tabletofwfile' :
            (ret,out,err) = dataMover.checkFileExists(config.tgt_path, config.tgt_in_local)
            if out.strip() == '0':
                valid = False
                log.error ("Target File %s already exists " %(config.tgt_path))
                        
            opDir = os.path.dirname(os.path.abspath(config.tgt_path))
            (ret,out,err) = dataMover.checkDirectoryExists(opDir, config.tgt_in_local)
            if out.strip() == '1':
                valid = False
                log.error ("Target Directory %s not exists" %(opDir))

        
        
        return valid
