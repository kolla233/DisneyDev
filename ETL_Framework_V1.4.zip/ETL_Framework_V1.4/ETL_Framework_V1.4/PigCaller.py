# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 15:45:52 2019

@author: krajkumar
"""

from Helper import Runcommand
from ds.logging.main import ETLLogger,getChild
from CustomExceptions import PigScriptException

pigexeclogger = getChild(ETLLogger,"PigExecLogger")

class PigCaller:
    
    def __init__(self):
        self.runcommand = Runcommand()
    
    def executePig(self, src_path, delimiter, src_schema, 
                                     add_schema, select_schema,
                                     tgt_delimiter, temp_directory_local) :
        pig_cmd = 'pig -param "path=\'{0}\'" -param "pigsourcedelimeter=\'{1}\'" -param "schema_file=\'{2}\'" -param "new_columns={3}" -param "selected_columns=\'{4}\'"  -param "target_path=\'{5}\'" -param "pigtargetdelimeter=\'{6}\'" -f \'new_pig/exe_new_dtod.pig\' '.format(src_path, delimiter,src_schema,add_schema,select_schema,temp_directory_local,tgt_delimiter)

        self.runcommand.run_cmd(pig_cmd, shell_cmd=True)
        
    def executePig1(self, move_type, src_path, src_reader, source_header, src_schema,add_schema, select_schema,tgt_writer, temp_directory_local,tgt_header) :
      
        
      pigexeclogger.debug("Started pig script execution")
      if move_type == "dfiletodfile":
          if source_header :
              source_header_option = 'SKIP_INPUT_HEADER'
          else :
              source_header_option = 'READ_INPUT_HEADER'
          
          if tgt_header:
              target_header_option = 'WRITE_OUTPUT_HEADER'
          else :
              target_header_option = 'SKIP_OUTPUT_HEADER'
              
          pig_cmd = 'pig -param "path=\'{0}\'" -param "pigsourcedelimeter=\'{1}\'" -param "sourceheader=\'{2}\'" -param "schema_file=\'{3}\'" -param "new_columns={4}" -param "selected_columns=\'{5}\'"  -param "target_path=\'{6}\'" -param "pigtargetdelimeter=\'{7}\'" -param "writeheader=\'{8}\'" -f \'new_pig/exe_new_dtod.pig\' '.format(src_path, src_reader ,source_header_option ,src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
          
      elif move_type == "dfiletofwfile":
          if source_header :
              source_header_option = 'SKIP_INPUT_HEADER'
          else :
              source_header_option = 'READ_INPUT_HEADER'
              
          if tgt_header:
              target_header_option = 'WRITE_HEADER'
          else :
              target_header_option = 'SKIP_HEADER'
              
          pig_cmd = 'pig -param "path=\'{0}\'" -param "pigsourcedelimeter=\'{1}\'" -param "sourceheader=\'{2}\'" -param "schema_file=\'{3}\'" -param "new_columns={4}" -param "selected_columns=\'{5}\'"  -param "target_path=\'{6}\'" -param "tgt_column_width=\'{7}\'"  -param "writeheader=\'{8}\'" -f \'new_pig/exe_new_dtofw.pig\' '.format(src_path, src_reader, source_header_option, src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
          
      elif move_type == "fwfiletodfile":
          if source_header :
              source_header_option = 'SKIP_HEADER'
          else :
              source_header_option = 'USE_HEADER'
              
          if tgt_header:
              target_header_option = 'WRITE_OUTPUT_HEADER'
          else :
              target_header_option = 'SKIP_OUTPUT_HEADER'
              
          pig_cmd = 'pig -param "path=\'{0}\'" -param "src_column_width=\'{1}\'" -param "sourceheader=\'{2}\'" -param "schema_file=\'{3}\'" -param "new_columns={4}" -param "selected_columns=\'{5}\'"  -param "target_path=\'{6}\'" -param "pigtargetdelimeter=\'{7}\'"  -param "writeheader=\'{8}\'" -f \'new_pig/exe_new_fwtod.pig\' '.format(src_path, src_reader, source_header_option, src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
          
      elif move_type == "fwfiletofwfile":
          if source_header :
              source_header_option = 'SKIP_HEADER'
          else :
              source_header_option = 'USE_HEADER'
          
          if tgt_header:
              target_header_option = 'WRITE_HEADER'
          else :
              target_header_option = 'SKIP_HEADER'
          pig_cmd = 'pig -param "path=\'{0}\'" -param "src_column_width=\'{1}\'" -param "sourceheader=\'{2}\'" -param "schema_file=\'{3}\'" -param "new_columns={4}" -param "selected_columns=\'{5}\'"  -param "target_path=\'{6}\'" -param "tgt_column_width=\'{7}\'" -param "writeheader=\'{8}\'" -f \'new_pig/exe_new_fwtofw.pig\' '.format(src_path, src_reader, source_header_option,src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
      
      elif move_type == "tabletodfile":
          if src_schema.strip() != "" :
              src_schema = " as({0}) ".format(src_schema)
              
          if tgt_header:
              target_header_option = 'WRITE_OUTPUT_HEADER'
          else :
              target_header_option = 'SKIP_OUTPUT_HEADER'
          
          pig_cmd = 'pig -useHCatalog -param "dbtable=\'{0}\'" -param "schema_file=\'{1}\'" -param "new_columns={2}" -param "selected_columns=\'{3}\'"  -param "target_path=\'{4}\'" -param "pigtargetdelimeter=\'{5}\'" -param "writeheader=\'{6}\'" -f \'new_pig/exe_new_tabletod.pig\' '.format(src_path,src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
      elif move_type == "tabletofwfile":
          if src_schema.strip() != "" :
              src_schema = " as({0}) ".format(src_schema)
          
          if tgt_header:
              target_header_option = 'WRITE_HEADER'
          else :
              target_header_option = 'SKIP_HEADER'
              
          pig_cmd = 'pig -useHCatalog -param "dbtable=\'{0}\'" -param "schema_file=\'{1}\'" -param "new_columns={2}" -param "selected_columns=\'{3}\'"  -param "target_path=\'{4}\'" -param "tgt_column_width=\'{5}\'" -param "writeheader=\'{6}\'" -f \'new_pig/exe_new_tabletofw.pig\' '.format(src_path,src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
      
      
      pigexeclogger.info("Final Pig Command is : \n %s" %(pig_cmd))
      s_return, s_output, s_err = self.runcommand.run_cmd(pig_cmd, shell_cmd=True)
      
      if s_return == 0:
          pigexeclogger.info("Completed pig script execution")
      else :
          pigexeclogger.error("Error in executing pig script ")
          raise PigScriptException("Pig script execution failed with error : '%s'" %(s_err))
     

    def executePigTable(self, move_type, src_path, src_reader, src_schema, 
                                     add_schema, select_schema,
                                     tgt_writer, temp_directory_local, tgt_header) :
        
        if move_type == "tabletodfile":
            if src_schema.strip() != "" :
                src_schema = " as({0}) ".format(src_schema)
            
            if tgt_header:
                target_header_option = 'WRITE_OUTPUT_HEADER'
            else :
                target_header_option = 'SKIP_OUTPUT_HEADER'
            
            pig_cmd = 'pig -useHCatalog -param "dbtable=\'{0}\'" -param "schema_file=\'{1}\'" -param "new_columns={2}" -param "selected_columns=\'{3}\'"  -param "target_path=\'{4}\'" -param "pigtargetdelimeter=\'{5}\'" -param "writeheader=\'{6}\'" -f \'exe_tabletod.pig\' '.format("rajdb.met",src_schema,add_schema,select_schema,temp_directory_local,tgt_writer, target_header_option)
        elif move_type == "tabletofwfile":
            if src_schema.strip() != "" :
                src_schema = " as({0}) ".format(src_schema)
            pig_cmd = 'pig -useHCatalog -param "dbtable=\'{0}\'" -param "schema_file=\'{1}\'" -param "new_columns={2}" -param "selected_columns=\'{3}\'"  -param "target_path=\'{4}\'" -param "tgt_column_width=\'{5}\'"  -f \'exe_tabletod.pig\' '.format(src_path,src_schema,add_schema,select_schema,temp_directory_local,tgt_writer)
        
        s_return, s_output, s_err = self.runcommand.run_cmd(pig_cmd, shell_cmd=True)
        
        if s_return == 0:
            print("execution of Pig Srcipt is completed. ")
        else :
            print("Error in executing pig script", s_err)

